# DebtForge — Deployment Guide

## Deploy to GitHub Pages

1. Create repo named `debtforge` on GitHub (Public)
2. Upload all files from this package
3. Settings → Pages → Deploy from branch: `main` / `/ (root)` → Save
4. Wait 2-3 min, then visit: `https://YOUR_USERNAME.github.io/debtforge/`

## Build Android App

### Option A: PWABuilder (no coding)
1. Go to https://www.pwabuilder.com
2. Enter your GitHub Pages URL
3. Package for Android → Package ID: `com.debtforge.app`
4. Download APK + AAB

### Option B: Bubblewrap (command line)
```bash
npm install -g @nicolo-ribaudo/nicolo-ribaudo-bubblewrap-cli
mkdir debtforge-android && cd debtforge-android
bubblewrap init --manifest https://YOUR_USERNAME.github.io/debtforge/manifest.json
bubblewrap build
```

## Domain Verification (Asset Links)

1. Get your SHA-256: `keytool -list -v -keystore ./pwa.keystore -alias pwa | grep SHA256`
2. Edit `.well-known/assetlinks.json` — replace placeholder fingerprints
3. After uploading to Google Play, add Google Play's SHA-256 as second fingerprint
4. Commit changes to GitHub

## Publish to Google Play

1. Create developer account at https://play.google.com/console ($25 one-time)
2. Create app → use text from `PLAY_STORE_LISTING.txt`
3. Upload AAB → complete all sections → submit for review
4. Privacy policy URL: `https://YOUR_USERNAME.github.io/debtforge/privacy.html`

## Updating the App

Edit files in GitHub → commit → app updates automatically (TWA loads your live site).
Only re-submit to Play Store if changing app name, icons, or Android config.
