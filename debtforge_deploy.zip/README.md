# 🔨 DebtForge

**Forge your path to financial freedom.**

DebtForge is a free, offline-first progressive web app that helps you take control of your debt and build a clear plan to eliminate it. It runs entirely in your browser with zero accounts, zero cloud storage, and zero data collection — your financial information never leaves your device. Compare five proven payoff strategies side-by-side, model what-if scenarios with raises and bonuses, import bank statements with smart auto-categorization, track your budget against your income, forecast your cash flow, and watch your net worth climb as your balances drop. Built for real people navigating real debt — not a toy calculator, but a serious financial tool that respects your privacy and works offline.

---

## Features

### 📊 Debt Tracking & Strategy
- Track unlimited debts: credit cards, personal loans, medical, auto, student loans, BNPL
- **5 payoff strategies** compared side-by-side: Avalanche, Snowball, Cash Flow, Credit Score, Promo Priority
- 0% promotional rate tracking with expiration alerts
- What-If calculator: model raises, bonuses, and extra payments
- Balance transfer, consolidation, and refinancing calculators
- Debt negotiation script generator

### 💰 Budget & Cash Flow
- Income vs. spending cross-check with visual breakdown
- Cash flow forecasting (30/60/90-day projections)
- Bill tracking with due date reminders
- Budget categories with spending analysis

### 🏦 Transaction Management
- Bank CSV import with 200+ auto-categorization patterns
- Manual re-categorization that trains the app over time
- Expense tracking with category breakdowns
- Handles separate debit/credit columns common in bank exports

### 📈 Net Worth & Assets
- Track assets alongside debts for full financial picture
- Auto-update balances from CSV imports
- Net worth trend visualization

### 🔒 Privacy & Security
- **100% offline** — no server, no analytics, no tracking
- All data stored in browser localStorage
- AES-256 encrypted backup export
- CSV data export
- Optional PIN protection

### 🎯 Motivation
- Daily check-ins and spending streaks
- Milestone celebrations
- Debt-free date countdown
- Progress visualization

---

## Quick Start

1. Visit the live app: `https://YOUR_USERNAME.github.io/debtforge/`
2. Add your debts (or load sample data to explore)
3. Set your monthly extra payment budget
4. Compare strategies and pick your plan
5. Import bank CSV files to auto-track spending

No signup. No download required. Works on any device with a modern browser.

### Install as App

- **Android/Chrome**: Menu → "Add to Home Screen" or "Install App"
- **iOS/Safari**: Share → "Add to Home Screen"
- **Desktop/Chrome**: Address bar install icon

---

## Tech Stack

- Vanilla JavaScript (no frameworks, no build step)
- HTML5 + CSS3 with CSS custom properties
- Service Worker for offline support
- Web App Manifest for installability
- localStorage for data persistence
- Web Crypto API for AES-256 encryption

---

## Project Structure

```
debtforge/
├── index.html           # Single-page app shell
├── manifest.json        # PWA manifest with all icon sizes
├── sw.js                # Service worker (offline support)
├── privacy.html         # Privacy policy
├── css/
│   └── styles.css       # All styles (~925 lines)
├── js/
│   └── app.js           # All logic (~2650 lines)
├── icons/               # 9 icon sizes including maskable
└── .well-known/
    └── assetlinks.json  # Android TWA domain verification
```

---

## Android App (Google Play)

DebtForge is a PWA that can be wrapped as a native Android app using [Bubblewrap](https://github.com/nicolo-ribaudo/nicolo-ribaudo-nicolo-ribaudo-bubblewrap-cli) or [PWABuilder](https://www.pwabuilder.com). See `DEPLOY_GUIDE.md` for step-by-step instructions.

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

## Privacy

DebtForge collects zero data. No analytics. No cookies. No server calls. Everything stays on your device. See [privacy.html](privacy.html) for the full privacy policy.

---

*Built with determination and JavaScript. No frameworks were harmed in the making of this app.*
