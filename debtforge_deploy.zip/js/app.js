// ============================================================
// DEBT FREEDOM VAULT V5.0 - ALL BUGS FIXED
// ============================================================

// INDEXEDDB STORAGE WITH LOCALSTORAGE FALLBACK
const Storage={
    db:null,
    DB_NAME:'DebtVaultDB',
    DB_VERSION:1,
    STORE_NAME:'vault',
    ready:false,
    
    async init(){
        return new Promise((resolve)=>{
            try{
                const request=indexedDB.open(this.DB_NAME,this.DB_VERSION);
                request.onerror=()=>{
                    console.warn('IndexedDB failed, using localStorage');
                    this.ready=false;
                    resolve();
                };
                request.onsuccess=()=>{
                    this.db=request.result;
                    this.ready=true;
                    resolve();
                };
                request.onupgradeneeded=(e)=>{
                    const db=e.target.result;
                    if(!db.objectStoreNames.contains(this.STORE_NAME)){
                        db.createObjectStore(this.STORE_NAME,{keyPath:'key'});
                    }
                };
            }catch(e){
                console.warn('IndexedDB not available');
                this.ready=false;
                resolve();
            }
        });
    },
    
    async get(key){
        if(this.ready&&this.db){
            return new Promise((resolve)=>{
                try{
                    const tx=this.db.transaction(this.STORE_NAME,'readonly');
                    const store=tx.objectStore(this.STORE_NAME);
                    const request=store.get(key);
                    request.onsuccess=()=>resolve(request.result?.value||null);
                    request.onerror=()=>resolve(localStorage.getItem(key));
                }catch(e){resolve(localStorage.getItem(key));}
            });
        }
        return localStorage.getItem(key);
    },
    
    async set(key,value){
        // Always save to localStorage as backup
        localStorage.setItem(key,value);
        
        if(this.ready&&this.db){
            return new Promise((resolve)=>{
                try{
                    const tx=this.db.transaction(this.STORE_NAME,'readwrite');
                    const store=tx.objectStore(this.STORE_NAME);
                    const request=store.put({key,value});
                    request.onsuccess=()=>resolve();
                    request.onerror=()=>resolve();
                }catch(e){resolve();}
            });
        }
    },
    
    async clear(){
        localStorage.removeItem('debtVault3');
        localStorage.removeItem('debtVaultHash3');
        if(this.ready&&this.db){
            try{
                const tx=this.db.transaction(this.STORE_NAME,'readwrite');
                const store=tx.objectStore(this.STORE_NAME);
                store.clear();
            }catch(e){}
        }
    }
};

// ENCRYPTION
const Crypto={
    async hash(pin){
        const enc=new TextEncoder().encode(pin+'debtVaultSalt2024');
        const hash=await crypto.subtle.digest('SHA-256',enc);
        return btoa(String.fromCharCode(...new Uint8Array(hash)));
    },
    
    async encrypt(data,pin){
        const key=await this.deriveKey(pin);
        const iv=crypto.getRandomValues(new Uint8Array(12));
        const enc=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,new TextEncoder().encode(JSON.stringify(data)));
        return btoa(String.fromCharCode(...iv)+String.fromCharCode(...new Uint8Array(enc)));
    },
    
    async decrypt(ciphertext,pin){
        try{
            const raw=atob(ciphertext);
            const iv=new Uint8Array([...raw.slice(0,12)].map(c=>c.charCodeAt(0)));
            const enc=new Uint8Array([...raw.slice(12)].map(c=>c.charCodeAt(0)));
            const key=await this.deriveKey(pin);
            const dec=await crypto.subtle.decrypt({name:'AES-GCM',iv},key,enc);
            return JSON.parse(new TextDecoder().decode(dec));
        }catch(e){return null;}
    },
    
    async deriveKey(pin){
        const keyMaterial=await crypto.subtle.importKey('raw',new TextEncoder().encode(pin),{name:'PBKDF2'},false,['deriveBits','deriveKey']);
        return crypto.subtle.deriveKey({name:'PBKDF2',salt:new TextEncoder().encode('debtVaultKey2024'),iterations:100000,hash:'SHA-256'},keyMaterial,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
    }
};

// CONSTANTS
const STORAGE_KEY='debtVault3';
const HASH_KEY='debtVaultHash3';

// STATE
let currentPin=null;
let data={
    debts:[],assets:[],transactions:[],budgetCategories:[],goals:[],bills:[],payments:[],
    achievements:{},streak:{count:0,lastCheck:null},
    settings:{darkMode:true,currency:'USD',autoLockMinutes:5,privacyOverlay:true},
    spendingByCategory:{},monthlyTotals:{}
};

// AUTO-LOCK
const AutoLock={
    timer:null,
    warningTimer:null,
    
    reset(){
        this.stop();
        if(!currentPin)return;
        const mins=data.settings?.autoLockMinutes||5;
        if(mins<=0)return;
        
        this.timer=setTimeout(()=>{
            this.showWarning();
        },(mins*60-30)*1000);
    },
    
    showWarning(){
        const el=document.getElementById('autoLockWarning');
        if(el)el.classList.add('show');
        this.warningTimer=setTimeout(()=>App.lock(),30000);
    },
    
    dismissWarning(){
        const el=document.getElementById('autoLockWarning');
        if(el)el.classList.remove('show');
        if(this.warningTimer)clearTimeout(this.warningTimer);
        this.reset();
    },
    
    stop(){
        if(this.timer)clearTimeout(this.timer);
        if(this.warningTimer)clearTimeout(this.warningTimer);
        this.timer=null;
        this.warningTimer=null;
    }
};

// PRIVACY
const Privacy={
    show(){
        if(data.settings?.privacyOverlay===false)return;
        const el=document.getElementById('privacyOverlay');
        if(el)el.classList.add('show');
    },
    hide(){
        const el=document.getElementById('privacyOverlay');
        if(el)el.classList.remove('show');
        AutoLock.reset();
    },
    isVisible(){
        const el=document.getElementById('privacyOverlay');
        return el&&el.classList.contains('show');
    }
};

// UTILITIES
function fmt(n){return'$'+(n||0).toLocaleString('en-US',{minimumFractionDigits:0,maximumFractionDigits:0})}

function calcStats(){
    const allDebts=data.debts||[];
    const eligible=getEligibleDebts();
    return{
        total:allDebts.reduce((s,d)=>s+d.balance,0),
        eligibleTotal:eligible.reduce((s,d)=>s+d.balance,0),
        monthlyInt:allDebts.reduce((s,d)=>s+(d.balance*d.rate/100/12),0),
        eligibleMonthlyInt:eligible.reduce((s,d)=>s+(d.balance*d.rate/100/12),0),
        count:allDebts.length,
        eligibleCount:eligible.length,
        avgRate:eligible.length>0?eligible.reduce((s,d)=>s+d.rate,0)/eligible.length:0
    };
}

function getEligibleDebts(){
    return(data.debts||[]).filter(d=>
        d.balance>0&&
        d.type!=='student'&&d.type!=='auto'&&d.type!=='mortgage'&&
        !d.excludeFromPlan
    );
}

function sortAvalanche(debts){
    return[...getEligibleDebts()].sort((a,b)=>{
        const aP=a.promoEnd&&new Date(a.promoEnd)<new Date(Date.now()+180*86400000);
        const bP=b.promoEnd&&new Date(b.promoEnd)<new Date(Date.now()+180*86400000);
        if(aP&&!bP)return-1;
        if(bP&&!aP)return 1;
        return b.rate-a.rate;
    });
}

// DATA MANAGER
const DataManager={
    async save(){
        if(!currentPin)return;
        const encrypted=await Crypto.encrypt(data,currentPin);
        await Storage.set(STORAGE_KEY,encrypted);
    },
    
    async load(){
        const encrypted=await Storage.get(STORAGE_KEY);
        if(!encrypted)return null;
        return await Crypto.decrypt(encrypted,currentPin);
    },
    
    async getHash(){
        return await Storage.get(HASH_KEY);
    },
    
    async setHash(hash){
        await Storage.set(HASH_KEY,hash);
    },
    
    async exportBackup(){
        const enc=await Crypto.encrypt(data,currentPin);
        const blob=new Blob([enc],{type:'application/octet-stream'});
        const a=document.createElement('a');
        a.href=URL.createObjectURL(blob);
        a.download='debtforge-'+new Date().toISOString().split('T')[0]+'.dfbackup';
        a.click();
        UI.toast('✓ Backup saved!','success');
    },
    
    async importBackup(e){
        const file=e.target.files[0];
        if(!file)return;
        const reader=new FileReader();
        reader.onload=async ev=>{
            const dec=await Crypto.decrypt(ev.target.result,currentPin);
            if(dec&&dec.debts){
                data={...data,...dec};
                await this.save();
                App.renderAll();
                UI.toast('✓ Imported!','success');
            }else{
                UI.toast('Invalid file or wrong PIN','error');
            }
        };
        reader.readAsText(file);
    },
    
    async wipe(){
        if(!confirm('⚠️ DELETE ALL DATA? This cannot be undone!'))return;
        await Storage.clear();
        location.reload();
    }
};

// PIN MODULE
const PIN={
    entry:'',
    confirm:'',
    step:'enter',
    
    input(d){
        if(this.entry.length>=4)return;
        this.entry+=d;
        this.updateDisplay();
        if(this.entry.length===4)setTimeout(()=>this.handleComplete(),150);
    },
    
    backspace(){
        this.entry=this.entry.slice(0,-1);
        this.updateDisplay();
    },
    
    clear(){
        this.entry='';
        this.updateDisplay();
    },
    
    updateDisplay(){
        document.querySelectorAll('.pin-dot').forEach((dot,i)=>dot.classList.toggle('filled',i<this.entry.length));
    },
    
    async handleComplete(){
        if(this.step==='create'){
            this.confirm=this.entry;
            this.entry='';
            this.step='confirm';
            document.getElementById('lockTitle').textContent='Confirm PIN';
            document.getElementById('lockSubtitle').textContent='Enter again to confirm';
            this.updateDisplay();
        }else if(this.step==='confirm'){
            if(this.entry===this.confirm){
                currentPin=this.entry;
                await DataManager.setHash(await Crypto.hash(currentPin));
                data={debts:[],assets:[],transactions:[],budgetCategories:[],goals:[],bills:[],payments:[],achievements:{},streak:{count:0,lastCheck:null},settings:{darkMode:true,currency:'USD',autoLockMinutes:5,privacyOverlay:true},spendingByCategory:{},monthlyTotals:{}};
                await DataManager.save();
                App.unlock();
            }else{
                this.showError("PINs don't match");
                this.step='create';
                document.getElementById('lockTitle').textContent='Create PIN';
                this.confirm='';
            }
        }else{
            const hash=await Crypto.hash(this.entry);
            const stored=await DataManager.getHash();
            if(hash===stored){
                currentPin=this.entry;
                const loaded=await DataManager.load();
                if(loaded)data={...data,...loaded};
                App.unlock();
            }else{
                this.showError('Wrong PIN');
            }
        }
    },
    
    showError(msg){
        this.entry='';
        this.updateDisplay();
        document.getElementById('pinDisplay').classList.add('error-shake');
        document.getElementById('lockHelp').textContent=msg;
        document.getElementById('lockHelp').style.color='var(--danger)';
        setTimeout(()=>document.getElementById('pinDisplay').classList.remove('error-shake'),400);
    },
    
    async change(){
        const cur=document.getElementById('currentPin').value;
        const newP=document.getElementById('newPin').value;
        const conf=document.getElementById('confirmPin').value;
        if(newP.length!==4||!/^\d+$/.test(newP)){UI.toast('PIN must be 4 digits');return}
        if(newP!==conf){UI.toast("PINs don't match");return}
        const stored=await DataManager.getHash();
        if(await Crypto.hash(cur)!==stored){UI.toast('Wrong current PIN');return}
        currentPin=newP;
        await DataManager.setHash(await Crypto.hash(newP));
        await DataManager.save();
        Modals.close('pinChangeModal');
        UI.toast('✓ PIN changed!','success');
    }
};

// APP
const App={
    async init(){
        await Storage.init();
        const hash=await DataManager.getHash();
        
        if(!hash){
            PIN.step='create';
            document.getElementById('lockTitle').textContent='Create PIN';
            document.getElementById('lockSubtitle').textContent='Choose a 4-digit PIN';
            document.getElementById('lockHelp').textContent='This encrypts all your data';
        }else{
            PIN.step='enter';
            document.getElementById('lockTitle').textContent='Enter PIN';
            document.getElementById('lockSubtitle').textContent='Enter your 4-digit PIN';
        }
    },
    
    unlock(){
        document.getElementById('lockScreen').style.display='none';
        document.getElementById('mainApp').style.display='block';
        document.getElementById('bottomNav').style.display='flex';
        Privacy.hide();
        Settings.applyTheme();
        AutoLock.reset();
        this.renderAll();
    },
    
    lock(){
        AutoLock.stop();
        const warning=document.getElementById('autoLockWarning');
        if(warning)warning.classList.remove('show');
        currentPin=null;
        PIN.entry='';
        PIN.step='enter';
        document.getElementById('lockScreen').style.display='flex';
        document.getElementById('mainApp').style.display='none';
        document.getElementById('bottomNav').style.display='none';
        document.getElementById('lockTitle').textContent='Enter PIN';
        document.getElementById('lockSubtitle').textContent='Enter your 4-digit PIN';
        document.getElementById('lockHelp').textContent='';
        PIN.updateDisplay();
    },
    
    renderAll(){
        try{
            Dashboard.render();
            Debts.render();
            Assets.render();
            Budget.render();
            Transactions.render();
            Strategy.calculateAll();
            Goals.render();
            Bills.render();
            Calendar.render();
            Achievements.render();
        }catch(e){console.error('Render error:',e);}
    }
};

// NAV
const Nav={
    show(section,btn){
        document.querySelectorAll('.tab-content').forEach(s=>s.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
        document.getElementById(section+'-section').classList.add('active');
        if(btn)btn.classList.add('active');
        if(section==='strategy')Strategy.calculateAll();
        if(section==='budget')Analytics.renderSpendingChart();
    }
};

// UI
const UI={
    toast(msg,type='info'){
        const t=document.getElementById('toast');
        t.textContent=msg;
        t.className='toast '+type+' show';
        setTimeout(()=>t.classList.remove('show'),3000);
    },
    
    confetti(){
        const c=document.getElementById('confetti');
        c.innerHTML='';
        const colors=['#667eea','#764ba2','#38ef7d','#f5576c','#4facfe'];
        for(let i=0;i<50;i++){
            const p=document.createElement('div');
            p.className='confetti-piece';
            p.style.cssText='left:'+Math.random()*100+'%;background:'+colors[Math.floor(Math.random()*colors.length)]+';animation-delay:'+Math.random()*2+'s';
            c.appendChild(p);
        }
        setTimeout(()=>c.innerHTML='',3000);
    }
};

// MODALS
const Modals={
    show(id){document.getElementById(id).classList.add('show');},
    close(id){document.getElementById(id).classList.remove('show');},
    
    showDebt(id=null){
        if(id){
            const d=data.debts.find(x=>x.id===id);
            if(!d)return;
            document.getElementById('debtModalTitle').textContent='Edit Debt';
            document.getElementById('editingDebtId').value=id;
            document.getElementById('debtName').value=d.name;
            document.getElementById('debtBalance').value=d.balance;
            document.getElementById('debtRate').value=d.rate;
            document.getElementById('debtMinPayment').value=d.minPayment||'';
            document.getElementById('debtType').value=d.type||'credit';
            document.getElementById('debtDueDay').value=d.dueDay||'';
            document.getElementById('debtPromoEnd').value=d.promoEnd||'';
            document.getElementById('debtExcludeFromPlan').checked=d.excludeFromPlan||false;
        }else{
            document.getElementById('debtModalTitle').textContent='Add Debt';
            document.getElementById('editingDebtId').value='';
            ['debtName','debtBalance','debtRate','debtMinPayment','debtDueDay','debtPromoEnd'].forEach(i=>document.getElementById(i).value='');
            document.getElementById('debtType').value='credit';
            document.getElementById('debtExcludeFromPlan').checked=false;
        }
        this.show('debtModal');
    },
    
    showAsset(id=null){
        if(id){
            const a=data.assets.find(x=>x.id===id);
            if(!a)return;
            document.getElementById('assetModalTitle').textContent='Edit Asset';
            document.getElementById('editingAssetId').value=id;
            document.getElementById('assetName').value=a.name;
            document.getElementById('assetBalance').value=a.balance;
            document.getElementById('assetType').value=a.type||'checking';
        }else{
            document.getElementById('assetModalTitle').textContent='Add Asset';
            document.getElementById('editingAssetId').value='';
            ['assetName','assetBalance'].forEach(i=>document.getElementById(i).value='');
            document.getElementById('assetType').value='checking';
        }
        this.show('assetModal');
    },
    
    showPayment(){
        document.getElementById('paymentDate').value=new Date().toISOString().split('T')[0];
        document.getElementById('paymentAmount').value='';
        const sel=document.getElementById('paymentDebt');
        if(sel)sel.innerHTML=data.debts.map(d=>'<option value="'+d.id+'">'+d.name+' ('+fmt(d.balance)+')</option>').join('');
        this.show('paymentModal');
    },
    
    showGoal(id=null){
        if(id){
            const g=data.goals.find(x=>x.id===id);
            if(!g)return;
            document.getElementById('goalModalTitle').textContent='Edit Goal';
            document.getElementById('editingGoalId').value=id;
            document.getElementById('goalName').value=g.name;
            document.getElementById('goalTarget').value=g.target;
            document.getElementById('goalCurrent').value=g.current||0;
            document.getElementById('goalCategory').value=g.category||'other';
            document.getElementById('goalTargetDate').value=g.targetDate||'';
        }else{
            document.getElementById('goalModalTitle').textContent='Add Goal';
            document.getElementById('editingGoalId').value='';
            ['goalName','goalTarget','goalCurrent','goalTargetDate'].forEach(i=>document.getElementById(i).value='');
            document.getElementById('goalCategory').value='emergency';
        }
        this.show('goalModal');
    },
    
    showBill(id=null){
        if(id){
            const b=data.bills.find(x=>x.id===id);
            if(!b)return;
            document.getElementById('billModalTitle').textContent='Edit Bill';
            document.getElementById('editingBillId').value=id;
            document.getElementById('billName').value=b.name;
            document.getElementById('billAmount').value=b.amount;
            document.getElementById('billDueDay').value=b.dueDay;
            document.getElementById('billCategory').value=b.category||'other';
        }else{
            document.getElementById('billModalTitle').textContent='Add Bill';
            document.getElementById('editingBillId').value='';
            ['billName','billAmount','billDueDay'].forEach(i=>document.getElementById(i).value='');
            document.getElementById('billCategory').value='utilities';
        }
        this.show('billModal');
    },
    
    showPinChange(){
        ['currentPin','newPin','confirmPin'].forEach(i=>document.getElementById(i).value='');
        this.show('pinChangeModal');
    },
    
    showCSVImport(type){
        document.getElementById('csvImportType').value=type;
        document.getElementById('csvAccountName').value='';
        if(type==='debt'){
            document.getElementById('csvImportTitle').textContent='Import Debt from CSV';
            document.getElementById('csvDebtFields').style.display='block';
            document.getElementById('csvDebtFields2').style.display='grid';
            document.getElementById('csvAssetFields').style.display='none';
        }else{
            document.getElementById('csvImportTitle').textContent='Import Asset from CSV';
            document.getElementById('csvDebtFields').style.display='none';
            document.getElementById('csvDebtFields2').style.display='none';
            document.getElementById('csvAssetFields').style.display='block';
        }
        this.show('csvImportModal');
    }
};

// DASHBOARD
const Dashboard={
    render(){
        this.renderCountdown();
        this.renderInsight();
        this.renderStats();
        this.renderProgress();
    },
    
    renderCountdown(){
        const eligible=getEligibleDebts();
        const allDebts=(data.debts||[]).filter(d=>d.balance>0);
        const extra=parseFloat(document.getElementById('strategyExtra')?.value)||500;
        
        if(eligible.length===0&&allDebts.length===0){
            document.getElementById('freedomDate').textContent='Add debts to start';
            document.getElementById('freedomDays').textContent='';
            document.getElementById('freedomSub').textContent='';
            document.getElementById('totalDebtFreedom').innerHTML='';
            return;
        }
        
        const now=new Date();
        
        if(eligible.length>0){
            const result=Strategy.simulate(eligible,extra,'avalanche');
            const days=Math.ceil((result.freedomDate-now)/86400000);
            const yrs=Math.floor(days/365);
            const mos=Math.floor((days%365)/30);
            
            document.getElementById('freedomDate').textContent=result.freedomDate.toLocaleDateString('en-US',{month:'short',year:'numeric'});
            document.getElementById('freedomDays').textContent=days.toLocaleString()+' days';
            document.getElementById('freedomSub').textContent=(yrs>0?yrs+'y '+mos+'m':mos+'m')+' with '+fmt(extra)+'/mo extra';
        }else{
            document.getElementById('freedomDate').textContent='Consumer debt free! 🎉';
            document.getElementById('freedomDays').textContent='';
            document.getElementById('freedomSub').textContent='';
        }
        
        // Total debt section
        const el=document.getElementById('totalDebtFreedom');
        const hasOther=allDebts.some(d=>d.type==='student'||d.type==='auto'||d.type==='mortgage');
        if(hasOther&&allDebts.length>0){
            const result=Strategy.simulateAll(allDebts,extra,'avalanche');
            const days=Math.ceil((result.freedomDate-now)/86400000);
            const yrs=Math.floor(days/365);
            const mos=Math.floor((days%365)/30);
            el.innerHTML='<div class="total-debt-label">TOTAL DEBT FREE</div><div class="total-debt-date">'+result.freedomDate.toLocaleDateString('en-US',{month:'short',year:'numeric'})+'</div><div class="total-debt-time">'+(yrs>0?yrs+'y '+mos+'m':mos+'m')+'</div>';
        }else{
            el.innerHTML='';
        }
    },
    
    renderInsight(){
        const insights=Insights.generate();
        const el=document.getElementById('aiInsightText');
        if(insights.length===0){
            el.innerHTML='Add debts to get personalized insights!';
            return;
        }
        const top=insights[0];
        el.innerHTML='<div class="insight-title">'+top.icon+' '+top.title+'</div><div class="insight-text">'+top.text+'</div>'+
            (top.actions?'<div class="insight-actions">'+top.actions.map(a=>'<button class="btn btn-sm" onclick="'+a.action+'">'+a.text+'</button>').join('')+'</div>':'');
    },
    
    renderStats(){
        const s=calcStats();
        document.getElementById('dashboardStats').innerHTML=
            '<div class="stat-card danger"><div class="stat-value">'+fmt(s.eligibleTotal)+'</div><div class="stat-label">Consumer Debt</div></div>'+
            '<div class="stat-card warning"><div class="stat-value">'+fmt(s.eligibleMonthlyInt)+'</div><div class="stat-label">Monthly Interest</div></div>'+
            '<div class="stat-card info"><div class="stat-value">'+s.eligibleCount+'</div><div class="stat-label">Accounts</div></div>'+
            '<div class="stat-card success"><div class="stat-value">'+s.avgRate.toFixed(1)+'%</div><div class="stat-label">Avg Rate</div></div>';
    },
    
    renderProgress(){
        const eligible=getEligibleDebts();
        const orig=eligible.reduce((s,d)=>s+(d.originalBalance||d.balance),0);
        const curr=eligible.reduce((s,d)=>s+d.balance,0);
        const paid=orig-curr;
        const pct=orig>0?(paid/orig*100):0;
        
        document.getElementById('progressFill').style.width=Math.min(pct,100)+'%';
        document.getElementById('progressFill').textContent=pct.toFixed(0)+'%';
        document.getElementById('paidAmount').textContent=fmt(paid)+' paid';
        document.getElementById('remainingAmount').textContent=fmt(curr)+' remaining';
    }
};

// INSIGHTS
const Insights={
    generate(){
        const insights=[];
        const eligible=getEligibleDebts();
        
        if(eligible.length===0)return insights;
        
        // Promo expiring
        eligible.filter(d=>d.promoEnd).forEach(d=>{
            const days=Math.ceil((new Date(d.promoEnd)-new Date())/86400000);
            if(days>0&&days<=180){
                const mos=Math.ceil(days/30);
                insights.push({
                    priority:1,type:'danger',icon:'🚨',
                    title:d.name+' - 0% APR Expiring',
                    text:'Pay '+fmt(d.balance/mos)+'/mo for '+mos+' months to avoid deferred interest.',
                    actions:[{text:'Make payment',action:'Modals.showPayment()'}]
                });
            }
        });
        
        // High interest
        const high=eligible.filter(d=>d.rate>=20).sort((a,b)=>b.rate-a.rate);
        if(high.length>0){
            const worst=high[0];
            insights.push({
                priority:2,type:'warning',icon:'💸',
                title:'High Interest: '+worst.name,
                text:worst.rate+'% APR costs '+fmt(worst.balance*worst.rate/100/12)+'/mo in interest.',
                actions:[{text:'Pay extra',action:'Modals.showPayment()'}]
            });
        }
        
        // Quick wins
        const small=eligible.filter(d=>d.balance<1500).sort((a,b)=>a.balance-b.balance);
        if(small.length>0){
            insights.push({
                priority:3,type:'success',icon:'🎯',
                title:'Quick Win: '+small[0].name,
                text:'Only '+fmt(small[0].balance)+' left! Pay it off to free up cash.',
                actions:[{text:'Pay off',action:'Modals.showPayment()'}]
            });
        }
        
        return insights.sort((a,b)=>a.priority-b.priority);
    },
    
    renderPanel(){
        const insights=this.generate();
        const el=document.getElementById('insightsPanel');
        if(!el)return;
        if(insights.length===0){
            el.innerHTML='<p style="color:var(--text-muted)">Add debts to see actionable insights</p>';
            return;
        }
        el.innerHTML=insights.map(i=>'<div class="insight-card '+i.type+'"><div class="insight-title">'+i.icon+' '+i.title+'</div><div class="insight-text">'+i.text+'</div>'+(i.actions?'<div class="insight-actions">'+i.actions.map(a=>'<button class="btn btn-sm" onclick="'+a.action+'">'+a.text+'</button>').join('')+'</div>':'')+'</div>').join('');
    }
};

// DEBTS
const Debts={
    render(){
        const tbody=document.getElementById('debtsBody');
        const empty=document.getElementById('debtsEmpty');
        
        if(!data.debts||data.debts.length===0){
            if(empty)empty.style.display='block';
            tbody.innerHTML='';
            return;
        }
        if(empty)empty.style.display='none';
        
        const eligible=sortAvalanche(data.debts);
        const excluded=(data.debts||[]).filter(d=>d.type==='student'||d.type==='auto'||d.type==='mortgage'||d.excludeFromPlan);
        const all=[...eligible,...excluded.filter(d=>!eligible.includes(d))];
        
        tbody.innerHTML=all.map(d=>{
            const isExcluded=d.type==='student'||d.type==='auto'||d.type==='mortgage'||d.excludeFromPlan;
            const priority=isExcluded?'—':(eligible.indexOf(d)+1);
            return'<tr style="'+(isExcluded?'opacity:0.6':'')+'">'+
                '<td><span class="badge '+(isExcluded?'badge-info':priority<=3?'badge-danger':'badge-success')+'">'+priority+'</span></td>'+
                '<td><strong>'+d.name+'</strong><div style="font-size:10px;color:var(--text-muted)">'+d.type+(isExcluded?' • excluded':'')+'</div></td>'+
                '<td class="balance debt">'+fmt(d.balance)+'</td>'+
                '<td>'+d.rate+'%</td>'+
                '<td><button class="action-btn" onclick="Modals.showDebt('+d.id+')">✏️</button><button class="action-btn" onclick="DebtNegotiation.show('+d.id+')" title="Negotiate">📞</button><button class="action-btn" onclick="Debts.delete('+d.id+')">🗑️</button></td></tr>';
        }).join('');
    },
    
    save(){
        const name=document.getElementById('debtName').value.trim();
        const balance=parseFloat(document.getElementById('debtBalance').value);
        const rate=parseFloat(document.getElementById('debtRate').value);
        if(!name||isNaN(balance)||isNaN(rate)){UI.toast('Fill required fields');return}
        
        const debtType=document.getElementById('debtType').value;
        const excludeFromPlan=document.getElementById('debtExcludeFromPlan').checked||
            debtType==='student'||debtType==='auto'||debtType==='mortgage';
        
        const debt={
            name,balance,rate,
            originalBalance:balance,
            minPayment:parseFloat(document.getElementById('debtMinPayment').value)||0,
            type:debtType,
            dueDay:parseInt(document.getElementById('debtDueDay').value)||null,
            promoEnd:document.getElementById('debtPromoEnd').value||null,
            excludeFromPlan
        };
        
        const editId=document.getElementById('editingDebtId').value;
        if(editId){
            const idx=data.debts.findIndex(d=>d.id===parseInt(editId));
            if(idx>=0){debt.id=parseInt(editId);debt.originalBalance=data.debts[idx].originalBalance||balance;data.debts[idx]=debt;}
        }else{
            debt.id=Date.now();
            data.debts.push(debt);
            Achievements.check('first_debt');
        }
        
        DataManager.save();
        Modals.close('debtModal');
        App.renderAll();
        UI.toast('✓ Saved!','success');
    },
    
    delete(id){
        if(!confirm('Delete this debt?'))return;
        data.debts=data.debts.filter(d=>d.id!==id);
        DataManager.save();
        App.renderAll();
    }
};

// ASSETS
const Assets={
    render(){
        const tbody=document.getElementById('assetsBody');
        const empty=document.getElementById('assetsEmpty');
        
        if(!data.assets||data.assets.length===0){
            if(empty)empty.style.display='block';
            tbody.innerHTML='';
            NetWorth.render();
            return;
        }
        if(empty)empty.style.display='none';
        
        tbody.innerHTML=data.assets.map(a=>
            '<tr><td><strong>'+a.name+'</strong><div style="font-size:10px;color:var(--text-muted)">'+a.type+'</div></td>'+
            '<td class="balance asset">'+fmt(a.balance)+'</td>'+
            '<td><button class="action-btn" onclick="Modals.showAsset('+a.id+')">✏️</button><button class="action-btn" onclick="Assets.delete('+a.id+')">🗑️</button></td></tr>'
        ).join('');
        
        NetWorth.render();
    },
    
    save(){
        const name=document.getElementById('assetName').value.trim();
        const balance=parseFloat(document.getElementById('assetBalance').value);
        if(!name||isNaN(balance)){UI.toast('Fill required fields');return}
        
        const asset={name,balance,type:document.getElementById('assetType').value};
        
        const editId=document.getElementById('editingAssetId').value;
        if(editId){
            const idx=data.assets.findIndex(a=>a.id===parseInt(editId));
            if(idx>=0){asset.id=parseInt(editId);data.assets[idx]=asset;}
        }else{
            asset.id=Date.now();
            data.assets.push(asset);
        }
        
        DataManager.save();
        Modals.close('assetModal');
        App.renderAll();
        UI.toast('✓ Saved!','success');
    },
    
    delete(id){
        if(!confirm('Delete this asset?'))return;
        data.assets=data.assets.filter(a=>a.id!==id);
        DataManager.save();
        App.renderAll();
    }
};

// NET WORTH
const NetWorth={
    render(){
        const totalAssets=(data.assets||[]).reduce((s,a)=>s+a.balance,0);
        const totalDebts=(data.debts||[]).reduce((s,d)=>s+d.balance,0);
        const netWorth=totalAssets-totalDebts;
        
        // Update assets section header
        const nwVal=document.getElementById('networthValue');
        if(nwVal)nwVal.textContent=fmt(netWorth);
        const ta=document.getElementById('totalAssets');
        if(ta)ta.textContent=fmt(totalAssets);
        const tl=document.getElementById('totalLiabilities');
        if(tl)tl.textContent='-'+fmt(totalDebts);
        
        // Update detailed net worth display
        const el=document.getElementById('netWorthDisplay');
        if(el){
            el.innerHTML='<h3>Net Worth Breakdown</h3>'+
                '<div class="net-worth-row"><span>Total Assets</span><span class="asset">'+fmt(totalAssets)+'</span></div>'+
                '<div class="net-worth-row"><span>Total Debts</span><span class="debt">-'+fmt(totalDebts)+'</span></div>'+
                '<div class="net-worth-row total"><span>Net Worth</span><span style="color:'+(netWorth>=0?'var(--success)':'var(--danger)')+'">'+fmt(netWorth)+'</span></div>';
        }
        
        if(netWorth>=0&&totalDebts>0)Achievements.check('positive_networth');
    }
};

// PAYMENTS
const Payments={
    save(){
        const debtId=parseInt(document.getElementById('paymentDebt').value);
        const amount=parseFloat(document.getElementById('paymentAmount').value);
        const date=document.getElementById('paymentDate').value;
        
        if(!debtId||isNaN(amount)||amount<=0){UI.toast('Enter valid amount');return}
        
        const debt=data.debts.find(d=>d.id===debtId);
        if(!debt){UI.toast('Debt not found');return}
        
        debt.balance=Math.max(0,debt.balance-amount);
        
        if(!data.payments)data.payments=[];
        data.payments.push({id:Date.now(),debtId,amount,date,debtName:debt.name});
        
        if(debt.balance===0){
            UI.toast('🎉 '+debt.name+' PAID OFF!','success');
            UI.confetti();
            Achievements.check('first_payoff');
        }else{
            UI.toast('✓ Payment recorded!','success');
        }
        
        DataManager.save();
        Modals.close('paymentModal');
        App.renderAll();
    }
};

// STRATEGY
const Strategy={
    simulate(debts,extra,method){
        return this._run(debts.filter(d=>d.type!=='student'&&d.type!=='auto'&&d.type!=='mortgage'),extra,method);
    },
    
    simulateAll(debts,extra,method){
        return this._run(debts,extra,method);
    },
    
    _run(debts,extra,method){
        if(debts.length===0)return{freedomDate:new Date(),totalInt:0,months:0,timeline:[]};
        
        let balances=debts.map(d=>({...d,bal:d.balance}));
        let totalInt=0,month=0;
        const timeline=[];
        const minPayments=balances.reduce((s,d)=>s+(d.minPayment||25),0);
        
        while(balances.some(d=>d.bal>0)&&month<360){
            month++;
            let available=minPayments+extra;
            
            // Apply interest
            balances.forEach(d=>{
                if(d.bal>0){
                    const int=d.bal*d.rate/100/12;
                    totalInt+=int;
                    d.bal+=int;
                }
            });
            
            // Sort by method
            if(method==='avalanche'){
                balances.sort((a,b)=>{
                    // Promo expiring within 6 months gets top priority
                    const aP=a.promoEnd&&new Date(a.promoEnd)<new Date(Date.now()+180*86400000);
                    const bP=b.promoEnd&&new Date(b.promoEnd)<new Date(Date.now()+180*86400000);
                    if(aP&&!bP)return-1;
                    if(bP&&!aP)return 1;
                    return b.rate-a.rate;
                });
            }else if(method==='snowball'){
                balances.sort((a,b)=>a.bal-b.bal);
            }else if(method==='highpayment'){
                balances.sort((a,b)=>(b.minPayment||25)-(a.minPayment||25));
            }else if(method==='highutil'){
                balances.sort((a,b)=>{
                    const aUtil=a.creditLimit?(a.bal/a.creditLimit):0.5;
                    const bUtil=b.creditLimit?(b.bal/b.creditLimit):0.5;
                    return bUtil-aUtil;
                });
            }else if(method==='promo'){
                balances.sort((a,b)=>{
                    const aExp=a.promoEnd?new Date(a.promoEnd).getTime():Infinity;
                    const bExp=b.promoEnd?new Date(b.promoEnd).getTime():Infinity;
                    if(aExp!==bExp)return aExp-bExp;
                    return b.rate-a.rate;
                });
            }
            
            // Pay minimums first
            balances.forEach(d=>{
                if(d.bal>0){
                    const min=Math.min(d.minPayment||25,d.bal);
                    d.bal-=min;
                    available-=min;
                }
            });
            
            // Extra to target
            for(const d of balances){
                if(d.bal>0&&available>0){
                    const pay=Math.min(available,d.bal);
                    d.bal-=pay;
                    available-=pay;
                    if(d.bal<=0){
                        timeline.push({name:d.name,month,date:new Date(Date.now()+month*30*86400000)});
                    }
                    break;
                }
            }
        }
        
        const freedomDate=new Date(Date.now()+month*30*86400000);
        return{freedomDate,totalInt,months:month,timeline};
    },
    
    calculateAll(){
        const extra=parseFloat(document.getElementById('strategyExtra')?.value)||500;
        const eligible=getEligibleDebts();
        
        Insights.renderPanel();
        
        if(eligible.length===0){
            document.getElementById('scenarioGrid').innerHTML='<p style="color:var(--text-muted)">Add eligible debts first.</p>';
            document.getElementById('payoffTimeline').innerHTML='';
            document.getElementById('whatIfResult').innerHTML='';
            return;
        }
        
        // Run all strategies
        const avalanche=this.simulate(eligible,extra,'avalanche');
        const snowball=this.simulate(eligible,extra,'snowball');
        const highPayment=this.simulate(eligible,extra,'highpayment');
        const highUtil=this.simulate(eligible,extra,'highutil');
        const promoFirst=this.simulate(eligible,extra,'promo');
        
        const strategies=[
            {key:'avalanche',name:'⚡ Avalanche',desc:'Highest rate first (saves most)',result:avalanche},
            {key:'snowball',name:'❄️ Snowball',desc:'Smallest balance first (quick wins)',result:snowball},
            {key:'highpayment',name:'💸 Cash Flow',desc:'Highest min payment first (frees cash)',result:highPayment},
            {key:'highutil',name:'📈 Credit Score',desc:'Highest utilization first',result:highUtil},
            {key:'promo',name:'⏰ Promo Priority',desc:'Expiring 0% promos first',result:promoFirst}
        ];
        
        // Sort by total interest to find the best
        const best=strategies.reduce((a,b)=>a.result.totalInt<=b.result.totalInt?a:b);
        const worst=strategies.reduce((a,b)=>a.result.totalInt>=b.result.totalInt?a:b);
        const maxSaving=worst.result.totalInt-best.result.totalInt;
        
        document.getElementById('scenarioGrid').innerHTML=strategies.map(s=>{
            const isBest=s.key===best.key;
            const timeDiff=s.result.months-best.result.months;
            const intDiff=s.result.totalInt-best.result.totalInt;
            return`<div class="scenario-card ${isBest?'active':''}">
                <div class="scenario-info"><h4>${s.name}${isBest?' ✅':''}</h4><p>${s.desc}</p></div>
                <div class="scenario-result">
                    <div class="date">${s.result.freedomDate.toLocaleDateString('en-US',{month:'short',year:'numeric'})}</div>
                    <div class="months">${s.result.months} months</div>
                    <div class="savings">${fmt(s.result.totalInt)} interest</div>
                    ${!isBest&&intDiff>50?`<div class="extra-cost">+${fmt(intDiff)} vs best</div>`:''}
                </div>
            </div>`;
        }).join('')+
        (maxSaving>100?`<div class="insight-card success"><div class="insight-title">💡 ${best.name.replace(/[^\w\s]/g,'')} saves ${fmt(maxSaving)} vs ${worst.name.replace(/[^\w\s]/g,'')}</div></div>`:'');
        
        // Show payoff timeline for the best strategy
        document.getElementById('payoffTimeline').innerHTML=`<h4>Payoff Order (${best.name})</h4>`+
            best.result.timeline.map((t,i)=>'<div class="timeline-item"><span class="timeline-num">'+(i+1)+'</span>'+
            '<span class="timeline-name">'+t.name+'</span><span class="timeline-date">'+t.date.toLocaleDateString('en-US',{month:'short',year:'numeric'})+'</span></div>').join('');
        
        // Inline What-If Calculator
        this.calculateWhatIf(eligible,extra,best);
    },
    
    calculateWhatIf(eligible,extra,bestStrategy){
        const el=document.getElementById('whatIfResult');
        if(!el)return;
        
        const raisePercent=parseFloat(document.getElementById('raisePercent')?.value)||0;
        const annualBonus=parseFloat(document.getElementById('annualBonus')?.value)||0;
        
        if(raisePercent===0&&annualBonus===0){
            el.innerHTML='<div class="insight-text">Enter a raise % or bonus amount above to see impact.</div>';
            return;
        }
        
        // Simulate with raise: each year, the monthly extra increases by raisePercent
        // and a lump sum bonus is applied
        let balances=eligible.map(d=>({...d,bal:d.balance}));
        let totalInt=0,month=0;
        const timeline=[];
        const minPayments=balances.reduce((s,d)=>s+(d.minPayment||25),0);
        let currentExtra=extra;
        let bonusApplied=false;
        
        while(balances.some(d=>d.bal>0)&&month<360){
            month++;
            
            // Apply annual raise and bonus at month 12, 24, 36...
            if(month%12===0){
                currentExtra=currentExtra*(1+raisePercent/100);
            }
            
            let available=minPayments+currentExtra;
            
            // Apply bonus once per year (month 12, 24, etc)
            if(month%12===1&&annualBonus>0&&month>1){
                available+=annualBonus;
            }
            
            // Interest
            balances.forEach(d=>{
                if(d.bal>0){const int=d.bal*d.rate/100/12;totalInt+=int;d.bal+=int;}
            });
            
            // Sort avalanche
            balances.sort((a,b)=>b.rate-a.rate);
            
            // Pay minimums
            balances.forEach(d=>{
                if(d.bal>0){const min=Math.min(d.minPayment||25,d.bal);d.bal-=min;available-=min;}
            });
            
            // Extra to target
            for(const d of balances){
                if(d.bal>0&&available>0){
                    const pay=Math.min(available,d.bal);
                    d.bal-=pay;available-=pay;
                    if(d.bal<=0)timeline.push({name:d.name,month,date:new Date(Date.now()+month*30*86400000)});
                    break;
                }
            }
        }
        
        const baseline=bestStrategy.result;
        const timeSaved=baseline.months-month;
        const intSaved=baseline.totalInt-totalInt;
        
        el.innerHTML=`
            <div class="whatif-inline">
                <div class="whatif-row"><span>With ${raisePercent}% annual raise${annualBonus>0?' + '+fmt(annualBonus)+' bonus':''}:</span></div>
                <div class="whatif-row highlight">
                    <span>Debt free: <strong>${new Date(Date.now()+month*30*86400000).toLocaleDateString('en-US',{month:'short',year:'numeric'})}</strong> (${month} mo)</span>
                </div>
                ${timeSaved>0?`<div class="whatif-row positive">⚡ ${timeSaved} months faster, saves ${fmt(intSaved)} in interest</div>`:''}
                ${timeSaved===0?`<div class="whatif-row">Same timeline — raises and bonuses offset by debt size</div>`:''}
                ${timeSaved<0?`<div class="whatif-row negative">⚠️ ${Math.abs(timeSaved)} months slower</div>`:''}
            </div>
        `;
    }
};

// BUDGET
const Budget={
    render(){
        this.renderOverview();
        const container=document.getElementById('budgetCategories');
        if(!container)return;
        
        if(!data.budgetCategories||data.budgetCategories.length===0){
            container.innerHTML='<p style="color:var(--text-muted)">No budget categories set up yet.</p>';
            return;
        }
        
        const thisMonth=new Date().getMonth();
        const thisYear=new Date().getFullYear();
        const icons={groceries:'🛒',dining:'🍽️',transport:'🚗',utilities:'💡',entertainment:'🎬',shopping:'🛍️',subscriptions:'📱',healthcare:'🏥',other:'📦'};
        
        container.innerHTML=data.budgetCategories.map(c=>{
            const spent=(data.transactions||[]).filter(t=>
                t.type==='expense'&&t.category===c.category&&
                new Date(t.date).getMonth()===thisMonth&&
                new Date(t.date).getFullYear()===thisYear
            ).reduce((s,t)=>s+t.amount,0);
            
            const pct=c.limit>0?(spent/c.limit*100):0;
            const status=pct>=100?'danger':pct>=80?'warning':'success';
            
            return'<div class="budget-category"><div class="budget-header">'+
                '<span>'+(icons[c.category]||'📦')+' '+c.category.charAt(0).toUpperCase()+c.category.slice(1)+'</span>'+
                '<span>'+fmt(spent)+' / '+fmt(c.limit)+'</span></div>'+
                '<div class="progress-bar"><div class="progress-fill '+status+'" style="width:'+Math.min(pct,100)+'%"></div></div></div>';
        }).join('');
    },
    
    renderOverview(){
        const el=document.getElementById('budgetOverview');
        if(!el)return;
        
        const monthlyIncome=Income.getMonthlyTotal();
        const totalBudgeted=(data.budgetCategories||[]).reduce((s,c)=>s+c.limit,0);
        const debtMinimums=(data.debts||[]).reduce((s,d)=>s+(d.minPayment||0),0);
        const billsTotal=(data.bills||[]).reduce((s,b)=>s+b.amount,0);
        const fixedCosts=debtMinimums+billsTotal;
        const totalCommitted=totalBudgeted+fixedCosts;
        const surplus=monthlyIncome-totalCommitted;
        
        if(monthlyIncome===0&&totalBudgeted===0){
            el.innerHTML='';
            return;
        }
        
        // Build visual breakdown
        const budgetPct=monthlyIncome>0?(totalBudgeted/monthlyIncome*100):0;
        const fixedPct=monthlyIncome>0?(fixedCosts/monthlyIncome*100):0;
        const surplusPct=monthlyIncome>0?Math.max(0,surplus/monthlyIncome*100):0;
        const overBudget=surplus<0;
        
        el.innerHTML=`
            <div class="budget-overview-card">
                <div class="budget-overview-title">💰 Income vs Budget</div>
                <div class="budget-overview-bar">
                    <div class="bo-segment bo-fixed" style="width:${Math.min(fixedPct,100)}%" title="Fixed costs"></div>
                    <div class="bo-segment bo-budget" style="width:${Math.min(budgetPct,100-Math.min(fixedPct,100))}%" title="Budgeted spending"></div>
                    ${!overBudget?`<div class="bo-segment bo-surplus" style="width:${surplusPct}%" title="Available for debt"></div>`:''}
                </div>
                <div class="budget-overview-legend">
                    <div class="bo-legend-item"><span class="bo-dot bo-fixed-dot"></span>Bills & Debt Min: ${fmt(fixedCosts)}</div>
                    <div class="bo-legend-item"><span class="bo-dot bo-budget-dot"></span>Budgeted: ${fmt(totalBudgeted)}</div>
                    <div class="bo-legend-item"><span class="bo-dot ${overBudget?'bo-danger-dot':'bo-surplus-dot'}"></span>${overBudget?'Over by: '+fmt(Math.abs(surplus)):'Available for extra debt payments: '+fmt(surplus)}</div>
                </div>
                <div class="budget-overview-row">
                    <span>Monthly Income</span><span class="bo-income">${fmt(monthlyIncome)}</span>
                </div>
                <div class="budget-overview-row">
                    <span>− Bills & Recurring</span><span>${fmt(billsTotal)}</span>
                </div>
                <div class="budget-overview-row">
                    <span>− Debt Minimums</span><span>${fmt(debtMinimums)}</span>
                </div>
                <div class="budget-overview-row">
                    <span>− Budgeted Spending</span><span>${fmt(totalBudgeted)}</span>
                </div>
                <div class="budget-overview-row total ${overBudget?'negative':'positive'}">
                    <span>${overBudget?'⚠️ Shortfall':'✅ Available for Debt Payoff'}</span>
                    <span>${overBudget?'-':''}${fmt(Math.abs(surplus))}/mo</span>
                </div>
                ${overBudget?`<div class="cashflow-warning" style="margin-top:12px">Your budget exceeds your income by ${fmt(Math.abs(surplus))}/mo. Review spending categories or add income sources.</div>`:''}
                ${!overBudget&&surplus>0?`<div class="budget-insight">At ${fmt(surplus)}/mo extra toward debt, you could pay off ${fmt(surplus*12)} per year beyond minimums.</div>`:''}
                ${monthlyIncome===0?`<div class="budget-insight warning">Add income sources in More → Income to see the full picture.</div>`:''}
            </div>
        `;
    },
    
    saveCategory(){
        const cat=document.getElementById('budgetCategorySelect').value;
        const limit=parseFloat(document.getElementById('budgetLimit').value);
        if(!cat||isNaN(limit)){UI.toast('Fill required fields');return}
        
        if(!data.budgetCategories)data.budgetCategories=[];
        const existing=data.budgetCategories.find(c=>c.category===cat);
        if(existing){
            existing.limit=limit;
        }else{
            data.budgetCategories.push({id:Date.now(),category:cat,limit});
        }
        
        DataManager.save();
        this.render();
        UI.toast('✓ Budget updated!','success');
        Achievements.check('budget_master');
    }
};

// TRANSACTIONS
const Transactions={
    render(){
        const container=document.getElementById('transactionsList');
        if(!container)return;
        
        // Hide/show the hardcoded empty state
        const emptyEl=document.getElementById('transactionsEmpty');
        if(emptyEl)emptyEl.style.display=(!data.transactions||data.transactions.length===0)?'block':'none';
        
        if(!data.transactions||data.transactions.length===0){
            container.innerHTML='';
            return;
        }
        
        const sorted=[...data.transactions].sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,50);
        const icons={groceries:'🛒',dining:'🍽️',transport:'🚗',utilities:'💡',entertainment:'🎬',shopping:'🛍️',subscriptions:'📱',income:'💰',healthcare:'🏥',transfer:'🔄',debt_payment:'💳',rent:'🏠',insurance:'🛡️',gas:'⛽',parking:'🅿️',personal_care:'💇',pets:'🐾',education:'📚',gifts:'🎁',charity:'❤️',fees:'🏦',other:'📦'};
        const categories=Object.keys(icons);
        
        container.innerHTML=sorted.map(t=>{
            const icon=icons[t.category]||'📦';
            return`<div class="transaction-item" data-id="${t.id}">
                <div class="transaction-icon">${icon}</div>
                <div class="transaction-details">
                    <div class="transaction-desc">${t.description}</div>
                    <div class="transaction-cat">
                        <select class="txn-cat-select" onchange="Transactions.recat(${t.id},this.value)" title="Change category">
                            ${categories.map(c=>`<option value="${c}"${t.category===c?' selected':''}>${icons[c]} ${c}</option>`).join('')}
                        </select>
                        <span class="txn-date"> • ${new Date(t.date).toLocaleDateString()}</span>
                    </div>
                </div>
                <div class="transaction-amount ${t.type==='income'?'income':'expense'}">${t.type==='income'?'+':'-'}${fmt(t.amount)}</div>
                <button class="txn-delete" onclick="Transactions.delete(${t.id})" title="Delete">×</button>
            </div>`;
        }).join('');
    },
    
    recat(id,newCategory){
        const txn=data.transactions.find(t=>t.id===id);
        if(!txn)return;
        
        const oldCat=txn.category;
        txn.category=newCategory;
        
        // Learn from manual recategorization
        if(!data.categoryRules)data.categoryRules=[];
        const desc=txn.description.toLowerCase();
        
        // Extract merchant name (first 2-3 significant words)
        const merchant=this.extractMerchant(desc);
        if(merchant){
            const existing=data.categoryRules.find(r=>r.merchant===merchant);
            if(existing){
                existing.category=newCategory;
                existing.count=(existing.count||1)+1;
            }else{
                data.categoryRules.push({merchant,category:newCategory,count:1});
            }
        }
        
        DataManager.save();
        Budget.render();
        Analytics.updateSpendingData();
        UI.toast(`✓ ${txn.description.substring(0,25)}... → ${newCategory}`,'success');
    },
    
    delete(id){
        data.transactions=data.transactions.filter(t=>t.id!==id);
        DataManager.save();
        this.render();
        Budget.render();
    },
    
    recategorizeAll(){
        if(!data.transactions||data.transactions.length===0){UI.toast('No transactions to categorize');return}
        let changed=0;
        data.transactions.forEach(t=>{
            const newCat=this.categorize(t.description);
            if(newCat!==t.category){changed++;t.category=newCat;}
        });
        DataManager.save();
        this.render();
        Budget.render();
        Analytics.updateSpendingData();
        UI.toast(`✓ Re-categorized ${changed} of ${data.transactions.length} transactions`,'success');
    },
    
    extractMerchant(desc){
        // Clean common bank prefixes and extract the core merchant name
        let clean=desc
            .replace(/^(pos |dbt |ach |chk |wire |pmnt |pmt |pymt |sq \*|tst\*|sp |pp\*|paypal \*)/i,'')
            .replace(/\d{6,}/g,'')  // remove long numbers (card numbers, refs)
            .replace(/\s{2,}/g,' ')
            .replace(/[#*]/g,'')
            .trim();
        
        // Take first 3 words as merchant identifier
        const words=clean.split(/\s+/).slice(0,3).join(' ').toLowerCase();
        return words.length>=3?words:null;
    },
    
    save(){
        const desc=document.getElementById('transactionDesc').value.trim();
        const amount=parseFloat(document.getElementById('transactionAmount').value);
        const type=document.getElementById('transactionType').value;
        const category=document.getElementById('transactionCategory').value;
        const date=document.getElementById('transactionDate').value||new Date().toISOString().split('T')[0];
        
        if(!desc||isNaN(amount)){UI.toast('Fill required fields');return}
        
        if(!data.transactions)data.transactions=[];
        data.transactions.push({id:Date.now(),description:desc,amount,type,category,date});
        
        DataManager.save();
        this.render();
        Budget.render();
        Analytics.updateSpendingData();
        UI.toast('✓ Added!','success');
        
        document.getElementById('transactionDesc').value='';
        document.getElementById('transactionAmount').value='';
    },
    
    importCSV(e){
        const file=e.target.files[0];
        if(!file)return;
        this.processCSV(file,null);
    },
    
    processCSV(file,callback){
        const reader=new FileReader();
        reader.onload=ev=>{
            const lines=ev.target.result.split('\n').filter(l=>l.trim());
            if(lines.length<2){UI.toast('Invalid CSV');return}
            
            const headers=lines[0].toLowerCase();
            let dateIdx=-1,descIdx=-1,amtIdx=-1,balIdx=-1,creditIdx=-1,debitIdx=-1;
            
            const cols=headers.split(',').map(c=>c.trim().replace(/"/g,''));
            cols.forEach((c,i)=>{
                if(c.includes('date')&&dateIdx<0)dateIdx=i;
                if((c.includes('description')||c.includes('memo')||c.includes('payee')||c.includes('merchant'))&&descIdx<0)descIdx=i;
                if(c.includes('amount')&&amtIdx<0)amtIdx=i;
                if(c.includes('balance')&&balIdx<0)balIdx=i;
                if(c==='credit'||c.includes('credit amount'))creditIdx=i;
                if(c==='debit'||c.includes('debit amount'))debitIdx=i;
            });
            
            // Some banks use separate debit/credit columns instead of a single amount
            if(amtIdx<0&&(debitIdx>=0||creditIdx>=0)){
                amtIdx=debitIdx>=0?debitIdx:creditIdx;
            }
            
            if(dateIdx<0||descIdx<0||amtIdx<0){UI.toast('Could not detect CSV format');return}
            
            const txns=[];
            let lastBalance=null;
            let totalIncome=0,totalExpense=0;
            
            for(let i=1;i<lines.length;i++){
                const parts=lines[i].match(/("([^"]*)"|[^,]+)/g)?.map(p=>p.replace(/^"|"$/g,'').trim());
                if(!parts||parts.length<=Math.max(dateIdx,descIdx,amtIdx))continue;
                
                const date=parts[dateIdx];
                const desc=parts[descIdx];
                let amt;
                
                // Handle separate debit/credit columns
                if(debitIdx>=0&&creditIdx>=0){
                    const debit=parseFloat((parts[debitIdx]||'0').replace(/[$,]/g,''))||0;
                    const credit=parseFloat((parts[creditIdx]||'0').replace(/[$,]/g,''))||0;
                    amt=credit>0?credit:-debit;
                }else{
                    amt=parseFloat(parts[amtIdx].replace(/[$,]/g,''));
                }
                
                if(isNaN(amt)||!desc)continue;
                
                // Track balance column
                if(balIdx>=0&&parts[balIdx]){
                    const bal=parseFloat(parts[balIdx].replace(/[$,]/g,''));
                    if(!isNaN(bal))lastBalance=bal;
                }
                
                const type=amt<0?'expense':'income';
                const absAmt=Math.abs(amt);
                if(type==='income')totalIncome+=absAmt;
                else totalExpense+=absAmt;
                const category=this.categorize(desc);
                
                txns.push({id:Date.now()+i,description:desc,amount:absAmt,type,category,date});
            }
            
            if(txns.length===0){UI.toast('No valid transactions found');return}
            
            if(!data.transactions)data.transactions=[];
            data.transactions.push(...txns);
            
            DataManager.save();
            this.render();
            Budget.render();
            Analytics.updateSpendingData();
            UI.toast('✓ Imported '+txns.length+' transactions','success');
            Achievements.check('import_csv');
            
            // Return balance info to caller
            if(callback){
                callback({
                    lastBalance,
                    totalIncome,
                    totalExpense,
                    netAmount:totalIncome-totalExpense,
                    txnCount:txns.length
                });
            }
        };
        reader.readAsText(file);
    },
    
    categorize(desc){
        const d=desc.toLowerCase();
        
        // 1. Check user-trained rules first (highest priority)
        if(data.categoryRules&&data.categoryRules.length>0){
            const merchant=this.extractMerchant(d);
            if(merchant){
                const rule=data.categoryRules.find(r=>merchant.includes(r.merchant)||r.merchant.includes(merchant));
                if(rule)return rule.category;
            }
        }
        
        // 2. Debt & bill payments (check first to prevent miscategorization)
        if(d.match(/capital one|amex|american express|discover|chase sapphire|citi card|barclays|synchrony|carecredit/))return'debt_payment';
        if(d.match(/upgrade.*payment|upgrade.*inc|sofi|lending club|prosper|earnest|upstart|avant/))return'debt_payment';
        if(d.match(/paypal.*inst|paypal.*xfer|paypal credit|affirm|afterpay|klarna|sezzle|zip pay/))return'debt_payment';
        if(d.match(/ford credit|ford motor|ally auto|toyota financial|honda financial/))return'debt_payment';
        if(d.match(/firstmark|nelnet|navient|mohela|great lakes|sallie mae|student loan/))return'debt_payment';
        if(d.match(/venmo repay|venmo payment|zelle.*(?:repay|payment)/))return'transfer';
        
        // 3. Transfers (not spending)
        if(d.match(/transfer|xfer|zelle|venmo|cashapp|cash app|paypal.*transfer|wire/))return'transfer';
        if(d.match(/atm|withdrawal|deposit/))return'transfer';
        
        // 4. Housing
        if(d.match(/rent|lease|apartment|property|hoa|homeowner|mortgage|zillow|realtor|nesbitt/))return'rent';
        
        // 5. Groceries (expanded)
        if(d.match(/walmart(?!.*com)|target(?!.*com)|costco|safeway|kroger|trader joe|whole foods|aldi|publix|wegmans|heb |h-e-b|food lion|giant|stop.?shop|shoprite|meijer|piggly|winn.?dixie|harris teeter|sprouts|fresh market|lidl|save.?a.?lot|food.*mart|grocery|supermarket/))return'groceries';
        
        // 6. Dining & food delivery (expanded)  
        if(d.match(/grubhub|doordash|uber eats|ubereats|postmates|seamless|caviar|instacart/))return'dining';
        if(d.match(/restaurant|cafe|coffee|starbucks|dunkin|mcdonald|burger king|wendy|chick.?fil|chipotle|taco bell|subway|panera|domino|pizza|sushi|thai|chinese|mexican|italian|indian|bbq|grill|diner|bistro|eatery|kitchen|bakery|deli|wingstop|popeye|five guys|shake shack|panda express|olive garden|applebee|chili|ihop|waffle|cracker barrel|outback|red lobster|texas roadhouse|cheesecake factory|chinagarden/))return'dining';
        if(d.match(/^sq\s?\*|^tst\*/))return'dining';  // Square/Toast = usually restaurants
        
        // 7. Transport & auto
        if(d.match(/uber(?!.*eats)|lyft|taxi|cab\b/))return'transport';
        if(d.match(/gas |gasoline|shell |chevron|exxon|mobil|bp |sunoco|marathon|speedway|wawa|sheetz|circle k|pilot|loves|racetrac|quiktrip|valero|citgo|phillips|arco|murphy/))return'gas';
        if(d.match(/atp |parking|parkme|park mobile|spothero|spot hero|meter|garage/))return'parking';
        if(d.match(/ez.?pass|toll|turnpike|metro|wmata|smartrip|transit|mta |bart |cta |septa/))return'transport';
        if(d.match(/jiffy lube|oil change|valvoline|midas|firestone|goodyear|discount tire|pep boys|autozone|advance auto|o'?reilly|napa |carmax/))return'transport';
        
        // 8. Utilities
        if(d.match(/electric|dominion energy|pepco|duke energy|pg&e|con ?edison|power|energy/))return'utilities';
        if(d.match(/water|sewer|trash|waste management|republic services/))return'utilities';
        if(d.match(/internet|comcast|xfinity|verizon fios|at&t.*internet|spectrum|cox|frontier|centurylink|google fiber/))return'utilities';
        if(d.match(/verizon(?!.*fios)|at&t(?!.*internet)|t-mobile|sprint|mint mobile|visible|us cellular|cricket|boost|metro.*pcs|phone.*bill/))return'utilities';
        
        // 9. Insurance
        if(d.match(/insurance|geico|progressive|state farm|allstate|usaa|liberty mutual|farmers|nationwide|traveler|hartford|aetna|cigna|united health|anthem|kaiser|blue cross|humana|metlife/))return'insurance';
        
        // 10. Subscriptions & streaming
        if(d.match(/netflix|spotify|hulu|disney\+|disney plus|hbo|max\b|paramount|peacock|apple tv|youtube.*premium|audible|kindle|prime.*video/))return'subscriptions';
        if(d.match(/gym|planet fitness|equinox|orangetheory|crossfit|ymca|peloton|fitbit premium|strava/))return'subscriptions';
        if(d.match(/adobe|microsoft 365|office 365|google.*storage|dropbox|icloud|spotify|apple music|tidal|pandora/))return'subscriptions';
        if(d.match(/dave|davesubfee|chime|robinhood.*gold|betterment|wealthfront|copilot|ynab|mint|quicken/))return'subscriptions';
        if(d.match(/playstation.*plus|xbox.*game.*pass|nintendo.*online|twitch/))return'subscriptions';
        
        // 11. Shopping & retail
        if(d.match(/amazon(?!.*prime)|ebay|etsy|shop|mall|outlet|marshalls|tj.?maxx|ross|nordstrom|macy|kohls|jcpenney|old navy|gap\b|h&m|zara|uniqlo|forever 21|goodwill|thrift/))return'shopping';
        if(d.match(/home depot|lowes|menards|ace hardware|bed bath|ikea|wayfair|pottery barn|crate.*barrel|west elm|restoration hardware/))return'shopping';
        if(d.match(/best buy|apple\.com|apple store|micro center|newegg|b&h/))return'shopping';
        
        // 12. Healthcare
        if(d.match(/doctor|dr\.|physician|hospital|clinic|urgent care|emergency room|er\b|medical|health|dental|dentist|orthodont|optom|eye doctor|vision|pharmacy|cvs|walgreens|rite aid|prescription|rx\b|copay|labcorp|quest diagnostics|therapy|therapist|counselor|psychiatr|psycholog|chiropract/))return'healthcare';
        
        // 13. Personal care
        if(d.match(/hair|salon|barber|spa|nail|massage|wax|beauty|sephora|ulta|bath.*body/))return'personal_care';
        
        // 14. Pets
        if(d.match(/pet|vet|veterinar|petsmart|petco|chewy|dog|cat |puppy|kitten|animal hospital/))return'pets';
        
        // 15. Education
        if(d.match(/tuition|university|college|school|course|udemy|coursera|skillshare|masterclass|textbook|book/))return'education';
        
        // 16. Entertainment
        if(d.match(/movie|theater|theatre|cinema|amc|regal|concert|ticket|ticketmaster|stubhub|seatgeek|live nation|event|museum|zoo|aquarium|theme park|bowling|arcade|dave.*buster|topgolf|escape room/))return'entertainment';
        
        // 17. Gifts & charity
        if(d.match(/gift|present|hallmark|1-800.*flower|edible|donation|charit|church|tithe|offering|gofund|united way|red cross|salvation army/))return'gifts';
        
        // 18. Bank fees
        if(d.match(/overdraft|nsf|service charge|monthly fee|maintenance fee|atm fee|foreign transaction|late fee|interest charge/))return'fees';
        
        // 19. Income detection
        if(d.match(/payroll|salary|direct dep|ach.*deposit|irs.*refund|tax refund|employer|wage|compensation|stipend|commission/))return'income';
        if(d.match(/tiny jewel|cello|lesson|teaching|tutoring|freelance|1099/))return'income';
        
        return'other';
    },
    
    handleCSVImportWithAccount(e){
        const file=e.target.files[0];
        if(!file)return;
        
        const name=document.getElementById('csvAccountName').value.trim();
        if(!name){UI.toast('Enter account name');return}
        
        const importType=document.getElementById('csvImportType').value;
        
        this.processCSV(file,(result)=>{
            if(!result)return;
            
            // Determine balance: prefer balance column from CSV, fallback to net transactions
            const detectedBalance=result.lastBalance!==null?Math.abs(result.lastBalance):result.totalExpense;
            
            if(importType==='debt'){
                const rate=parseFloat(document.getElementById('csvDebtRate').value)||0;
                const min=parseFloat(document.getElementById('csvDebtMinPayment').value)||0;
                const debtType=document.getElementById('csvDebtType').value;
                
                // Check if this debt already exists (by name)
                const existing=data.debts.find(d=>d.name.toLowerCase()===name.toLowerCase());
                if(existing){
                    existing.balance=detectedBalance;
                    UI.toast('✓ Updated '+name+' balance to '+fmt(detectedBalance),'success');
                }else{
                    data.debts.push({
                        id:Date.now(),
                        name,balance:detectedBalance,originalBalance:detectedBalance,rate,minPayment:min,type:debtType,
                        excludeFromPlan:debtType==='student'||debtType==='auto'||debtType==='mortgage'
                    });
                    UI.toast('✓ Added '+name+' with balance '+fmt(detectedBalance),'success');
                }
            }else{
                // For assets, use balance column if found, otherwise use net amount
                const assetBalance=result.lastBalance!==null?result.lastBalance:result.netAmount;
                
                // Check if this asset already exists
                const existing=data.assets.find(a=>a.name.toLowerCase()===name.toLowerCase());
                if(existing){
                    existing.balance=assetBalance;
                    UI.toast('✓ Updated '+name+' balance to '+fmt(assetBalance),'success');
                }else{
                    data.assets.push({id:Date.now(),name,balance:assetBalance,type:document.getElementById('csvAssetType').value});
                    UI.toast('✓ Added '+name+' with balance '+fmt(assetBalance),'success');
                }
            }
            
            Modals.close('csvImportModal');
            DataManager.save();
            App.renderAll();
        });
    }
};

// ANALYTICS
const Analytics={
    updateSpendingData(){
        const thisMonth=new Date().getMonth();
        const thisYear=new Date().getFullYear();
        data.spendingByCategory={};
        (data.transactions||[]).filter(t=>
            t.type==='expense'&&
            new Date(t.date).getMonth()===thisMonth&&
            new Date(t.date).getFullYear()===thisYear
        ).forEach(t=>{
            data.spendingByCategory[t.category]=(data.spendingByCategory[t.category]||0)+t.amount;
        });
    },
    
    renderSpendingChart(){
        const el=document.getElementById('spendingChart');
        if(!el)return;
        
        this.updateSpendingData();
        const cats=Object.entries(data.spendingByCategory||{}).sort((a,b)=>b[1]-a[1]);
        
        if(cats.length===0){
            el.innerHTML='<p style="color:var(--text-muted);text-align:center">Import transactions to see spending analysis</p>';
            return;
        }
        
        const total=cats.reduce((s,c)=>s+c[1],0);
        const icons={groceries:'🛒',dining:'🍽️',transport:'🚗',utilities:'💡',entertainment:'🎬',shopping:'🛍️',subscriptions:'📱',other:'📦'};
        
        el.innerHTML='<h4>This Month</h4>'+cats.map(([cat,amt])=>
            '<div style="display:flex;align-items:center;margin:8px 0"><span style="width:24px">'+(icons[cat]||'📦')+'</span>'+
            '<span style="flex:1">'+cat+'</span><span style="font-weight:600">'+fmt(amt)+'</span>'+
            '<span style="width:50px;text-align:right;color:var(--text-muted)">'+(amt/total*100).toFixed(0)+'%</span></div>'
        ).join('')+'<div style="border-top:1px solid var(--border);margin-top:12px;padding-top:12px;display:flex;justify-content:space-between;font-weight:600"><span>Total</span><span>'+fmt(total)+'</span></div>';
    }
};

// GOALS
const Goals={
    render(){
        const el=document.getElementById('goalsList');
        const empty=document.getElementById('goalsEmpty');
        if(!el)return;
        
        if(!data.goals||data.goals.length===0){
            if(empty)empty.style.display='block';
            el.innerHTML='';
            return;
        }
        if(empty)empty.style.display='none';
        
        const icons={emergency:'🛡️',vacation:'✈️',house:'🏠',car:'🚗',other:'📦'};
        el.innerHTML=data.goals.map(g=>{
            const pct=g.target>0?(g.current/g.target*100):0;
            return'<div class="goal-card"><div class="goal-header">'+
                '<span style="font-size:24px">'+(icons[g.category]||'📦')+'</span>'+
                '<div style="flex:1"><div style="font-weight:600">'+g.name+'</div>'+
                '<div style="font-size:12px;color:var(--text-muted)">'+fmt(g.current)+' / '+fmt(g.target)+'</div></div>'+
                '<button class="action-btn" onclick="Modals.showGoal('+g.id+')">✏️</button></div>'+
                '<div class="progress-bar"><div class="progress-fill" style="width:'+Math.min(pct,100)+'%">'+pct.toFixed(0)+'%</div></div></div>';
        }).join('');
    },
    
    save(){
        const name=document.getElementById('goalName').value.trim();
        const target=parseFloat(document.getElementById('goalTarget').value);
        if(!name||isNaN(target)){UI.toast('Fill required fields');return}
        
        const goal={
            name,target,
            current:parseFloat(document.getElementById('goalCurrent').value)||0,
            category:document.getElementById('goalCategory').value,
            targetDate:document.getElementById('goalTargetDate').value||null
        };
        
        const editId=document.getElementById('editingGoalId').value;
        if(editId){
            const idx=data.goals.findIndex(g=>g.id===parseInt(editId));
            if(idx>=0){goal.id=parseInt(editId);data.goals[idx]=goal;}
        }else{
            goal.id=Date.now();
            if(!data.goals)data.goals=[];
            data.goals.push(goal);
        }
        
        DataManager.save();
        Modals.close('goalModal');
        this.render();
        UI.toast('✓ Saved!','success');
    }
};

// BILLS
const Bills={
    render(){
        const el=document.getElementById('recurringBills');
        const upcoming=document.getElementById('upcomingBills');
        if(!el)return;
        
        if(!data.bills||data.bills.length===0){
            el.innerHTML='<div class="empty-state"><div class="empty-text">No bills yet</div></div>';
            if(upcoming)upcoming.innerHTML='';
            return;
        }
        
        const icons={housing:'🏠',utilities:'💡',insurance:'🛡️',subscriptions:'📱',other:'📦'};
        el.innerHTML=data.bills.map(b=>
            '<div class="transaction-item"><div class="transaction-icon">'+(icons[b.category]||'📦')+'</div>'+
            '<div class="transaction-details"><div class="transaction-desc">'+b.name+'</div>'+
            '<div class="transaction-cat">Due day '+b.dueDay+'</div></div>'+
            '<div class="transaction-amount expense">'+fmt(b.amount)+'</div>'+
            '<button class="action-btn" onclick="Modals.showBill('+b.id+')">✏️</button>'+
            '<button class="action-btn" onclick="Bills.delete('+b.id+')">🗑️</button></div>'
        ).join('');
        
        // Upcoming
        if(upcoming){
            const today=new Date().getDate();
            const sorted=[...data.bills].sort((a,b)=>{
                const ad=a.dueDay>=today?a.dueDay-today:a.dueDay+30-today;
                const bd=b.dueDay>=today?b.dueDay-today:b.dueDay+30-today;
                return ad-bd;
            }).slice(0,5);
            
            upcoming.innerHTML=sorted.map(b=>{
                const days=b.dueDay>=today?b.dueDay-today:b.dueDay+30-today;
                return'<div class="insight-card '+(days<=3?'danger':days<=7?'warning':'')+'">'+
                    '<div class="insight-title">'+b.name+'</div>'+
                    '<div class="insight-text">'+fmt(b.amount)+' • '+(days===0?'Due today':days+' days')+'</div></div>';
            }).join('');
        }
    },
    
    save(){
        const name=document.getElementById('billName').value.trim();
        const amount=parseFloat(document.getElementById('billAmount').value);
        const dueDay=parseInt(document.getElementById('billDueDay').value);
        if(!name||isNaN(amount)||isNaN(dueDay)){UI.toast('Fill required fields');return}
        
        const bill={name,amount,dueDay,category:document.getElementById('billCategory').value};
        
        const editId=document.getElementById('editingBillId').value;
        if(editId){
            const idx=data.bills.findIndex(b=>b.id===parseInt(editId));
            if(idx>=0){bill.id=parseInt(editId);data.bills[idx]=bill;}
        }else{
            bill.id=Date.now();
            if(!data.bills)data.bills=[];
            data.bills.push(bill);
        }
        
        DataManager.save();
        Modals.close('billModal');
        this.render();
        UI.toast('✓ Saved!','success');
    },
    
    delete(id){
        if(!confirm('Delete?'))return;
        data.bills=data.bills.filter(b=>b.id!==id);
        DataManager.save();
        this.render();
    }
};

// CALENDAR
let calendarDate=new Date();
const Calendar={
    render(){
        const grid=document.getElementById('calendarGrid');
        const monthEl=document.getElementById('calendarMonth');
        if(!grid)return;
        
        const year=calendarDate.getFullYear();
        const month=calendarDate.getMonth();
        if(monthEl)monthEl.textContent=calendarDate.toLocaleDateString('en-US',{month:'long',year:'numeric'});
        
        const firstDay=new Date(year,month,1).getDay();
        const daysInMonth=new Date(year,month+1,0).getDate();
        const today=new Date();
        
        let html=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d=>'<div class="calendar-header">'+d+'</div>').join('');
        for(let i=0;i<firstDay;i++)html+='<div class="calendar-day other-month"></div>';
        
        for(let d=1;d<=daysInMonth;d++){
            const isToday=d===today.getDate()&&month===today.getMonth()&&year===today.getFullYear();
            const hasBill=(data.bills||[]).some(b=>b.dueDay===d);
            const hasDebt=(data.debts||[]).some(x=>x.dueDay===d);
            html+='<div class="calendar-day'+(isToday?' today':'')+(hasBill||hasDebt?' has-event':'')+'">'+d+'</div>';
        }
        grid.innerHTML=html;
    },
    
    prev(){calendarDate.setMonth(calendarDate.getMonth()-1);this.render();},
    next(){calendarDate.setMonth(calendarDate.getMonth()+1);this.render();}
};

// ACHIEVEMENTS
const Achievements={
    list:[
        {id:'first_debt',name:'First Step',desc:'Add first debt',icon:'🎯'},
        {id:'first_payoff',name:'Victory!',desc:'Pay off a debt',icon:'🏆'},
        {id:'streak_7',name:'Week Warrior',desc:'7 day streak',icon:'🔥'},
        {id:'positive_networth',name:'In The Black',desc:'Positive net worth',icon:'💎'},
        {id:'budget_master',name:'Budget Boss',desc:'Set up budget',icon:'📊'},
        {id:'import_csv',name:'Data Wizard',desc:'Import CSV',icon:'🧙'}
    ],
    
    render(){
        const grid=document.getElementById('achievementGrid');
        const streak=document.getElementById('streakCount');
        if(!grid)return;
        
        grid.innerHTML=this.list.map(a=>
            '<div class="achievement'+(data.achievements&&data.achievements[a.id]?' unlocked':'')+'">'+
            '<div class="achievement-icon">'+a.icon+'</div>'+
            '<div class="achievement-name">'+a.name+'</div>'+
            '<div class="achievement-desc">'+a.desc+'</div></div>'
        ).join('');
        
        if(streak)streak.textContent=(data.streak?.count)||0;
    },
    
    check(id){
        if(!data.achievements)data.achievements={};
        if(data.achievements[id])return;
        data.achievements[id]=Date.now();
        DataManager.save();
        const a=this.list.find(x=>x.id===id);
        if(a)UI.toast('🏆 '+a.name+' unlocked!','success');
    },
    
    checkStreak(){
        if(!data.streak)data.streak={count:0,lastCheck:null};
        const today=new Date().toDateString();
        if(data.streak.lastCheck===today)return;
        const yesterday=new Date(Date.now()-86400000).toDateString();
        data.streak.count=data.streak.lastCheck===yesterday?data.streak.count+1:1;
        data.streak.lastCheck=today;
        if(data.streak.count>=7)this.check('streak_7');
        DataManager.save();
    }
};

// SETTINGS
const Settings={
    toggleDarkMode(){
        const toggle=document.getElementById('darkModeToggle');
        toggle.classList.toggle('active');
        data.settings.darkMode=toggle.classList.contains('active');
        this.applyTheme();
        DataManager.save();
    },
    
    applyTheme(){
        document.documentElement.setAttribute('data-theme',data.settings.darkMode?'dark':'light');
        const toggle=document.getElementById('darkModeToggle');
        if(toggle){
            if(data.settings.darkMode)toggle.classList.add('active');
            else toggle.classList.remove('active');
        }
        
        const autoLock=document.getElementById('autoLockSelect');
        if(autoLock)autoLock.value=data.settings.autoLockMinutes||5;
        
        const privacy=document.getElementById('privacyOverlayToggle');
        if(privacy){
            if(data.settings.privacyOverlay!==false)privacy.classList.add('active');
            else privacy.classList.remove('active');
        }
    },
    
    setAutoLock(mins){
        data.settings.autoLockMinutes=parseInt(mins);
        DataManager.save();
        AutoLock.reset();
        UI.toast('Auto-lock: '+(mins>0?mins+' min':'disabled'),'success');
    },
    
    togglePrivacyOverlay(){
        const toggle=document.getElementById('privacyOverlayToggle');
        toggle.classList.toggle('active');
        data.settings.privacyOverlay=toggle.classList.contains('active');
        DataManager.save();
        UI.toast('Privacy overlay '+(data.settings.privacyOverlay?'on':'off'),'success');
    }
};

// SHARE
const Share={
    showModal(){
        const stats=calcStats();
        const el=document.getElementById('sharePreview');
        el.innerHTML='<div style="text-align:center;padding:20px;background:linear-gradient(135deg,var(--accent),var(--accent-secondary));border-radius:12px;color:white">'+
            '<div style="font-size:24px;font-weight:700">🎯 Debt Freedom Journey</div>'+
            '<div style="margin-top:12px">'+stats.eligibleCount+' debts • '+fmt(stats.eligibleTotal)+' remaining</div></div>';
        Modals.show('shareModal');
    }
};

// PRESETS
const Presets={
    loadSample(){
        data.debts=[
            {id:1,name:'Capital One Quicksilver',balance:1931,originalBalance:1931,rate:28.74,minPayment:50,type:'credit',dueDay:15},
            {id:2,name:'Joint Amex',balance:7209,originalBalance:7209,rate:27.00,minPayment:180,type:'credit',dueDay:22},
            {id:3,name:'Wife Capital One',balance:8000,originalBalance:8000,rate:28.00,minPayment:200,type:'credit',dueDay:10},
            {id:4,name:'Wife Apple Card',balance:1000,originalBalance:1000,rate:20.00,minPayment:25,type:'credit',dueDay:18},
            {id:5,name:'Upgrade Personal Loan',balance:10876,originalBalance:10876,rate:19.77,minPayment:330,type:'personal',dueDay:5},
            {id:6,name:'CareCredit',balance:1053,originalBalance:1053,rate:0,minPayment:40,type:'medical',promoEnd:'2026-09-02',dueDay:2},
            {id:7,name:'PayPal #1',balance:2430,originalBalance:2430,rate:0,minPayment:77,type:'bnpl',dueDay:20},
            {id:8,name:'PayPal #2',balance:1862,originalBalance:1862,rate:0,minPayment:63,type:'bnpl',dueDay:20},
            {id:9,name:'Firstmark Student Loans',balance:45004,originalBalance:45004,rate:9.25,minPayment:725,type:'student',excludeFromPlan:true,dueDay:15},
            {id:10,name:'Ford Auto Loan',balance:14937,originalBalance:14937,rate:3.90,minPayment:408,type:'auto',excludeFromPlan:true,dueDay:1},
            {id:11,name:'Nelnet Federal',balance:75307,originalBalance:75307,rate:5.25,minPayment:0,type:'student',excludeFromPlan:true,dueDay:0}
        ];
        
        data.assets=[
            {id:1,name:'Emergency Fund',balance:1500,type:'emergency'},
            {id:2,name:'Checking',balance:2500,type:'checking'},
            {id:3,name:'Savings',balance:500,type:'savings'}
        ];
        
        data.bills=[
            {id:1,name:'Rent',amount:1850,dueDay:1,category:'housing'},
            {id:2,name:'Electric',amount:150,dueDay:15,category:'utilities'},
            {id:3,name:'Internet',amount:80,dueDay:20,category:'utilities'},
            {id:4,name:'Phone',amount:120,dueDay:25,category:'utilities'},
            {id:5,name:'Car Insurance',amount:180,dueDay:10,category:'insurance'},
            {id:6,name:'Netflix',amount:23,dueDay:18,category:'subscriptions'}
        ];
        
        data.goals=[
            {id:1,name:'Emergency Fund',target:5000,current:1500,category:'emergency'},
            {id:2,name:'Vacation',target:3000,current:0,category:'vacation'}
        ];
        
        data.budgetCategories=[
            {id:1,category:'groceries',limit:600},
            {id:2,category:'dining',limit:200},
            {id:3,category:'transport',limit:400},
            {id:4,category:'entertainment',limit:100}
        ];
        
        DataManager.save();
        App.renderAll();
        UI.toast('✓ Sample data loaded!','success');
        UI.confetti();
    }
};

// INITIALIZATION
document.addEventListener('visibilitychange',()=>{
    if(document.hidden&&currentPin)Privacy.show();
});

['click','keydown','touchstart','mousemove'].forEach(e=>{
    document.addEventListener(e,()=>{
        if(currentPin&&!Privacy.isVisible())AutoLock.reset();
    },{passive:true});
});

if('serviceWorker' in navigator){
    navigator.serviceWorker.register('sw.js').catch(()=>{});
}

App.init();

// ============================================================
// INCOME TRACKING
// ============================================================
const Income={
    render(){
        const el=document.getElementById('incomeList');
        const summary=document.getElementById('incomeSummary');
        if(!el)return;
        
        if(!data.income||data.income.length===0){
            el.innerHTML='<div class="empty-state"><div class="empty-text">No income sources yet</div><button class="btn btn-primary" onclick="Modals.showIncome()">+ Add Income</button></div>';
            if(summary)summary.innerHTML='';
            return;
        }
        
        const monthly=this.getMonthlyTotal();
        
        el.innerHTML=data.income.map(i=>{
            const monthlyAmt=this.toMonthly(i);
            return`<div class="income-item">
                <div class="income-info"><div class="income-name">${i.name}</div>
                <div class="income-freq">${i.frequency}${i.payDay?' • Day '+i.payDay:''}</div></div>
                <div class="income-amounts"><div class="income-per">${fmt(i.amount)}/${i.frequency==='weekly'?'wk':i.frequency==='biweekly'?'2wk':i.frequency==='annually'?'yr':'mo'}</div>
                <div class="income-monthly">${fmt(monthlyAmt)}/mo</div></div>
                <button class="action-btn" onclick="Modals.showIncome(${i.id})">✏️</button>
                <button class="action-btn" onclick="Income.delete(${i.id})">🗑️</button>
            </div>`;
        }).join('')+'<button class="btn btn-secondary" style="width:100%;margin-top:12px" onclick="Modals.showIncome()">+ Add Income Source</button>';
        
        if(summary)summary.innerHTML=`<div class="income-total"><span>Total Monthly Income</span><span class="amount">${fmt(monthly)}</span></div>`;
    },
    
    toMonthly(i){
        if(i.frequency==='weekly')return i.amount*52/12;
        if(i.frequency==='biweekly')return i.amount*26/12;
        if(i.frequency==='semimonthly')return i.amount*2;
        if(i.frequency==='annually')return i.amount/12;
        return i.amount;
    },
    
    getMonthlyTotal(){
        return(data.income||[]).reduce((s,i)=>s+this.toMonthly(i),0);
    },
    
    save(){
        const name=document.getElementById('incomeName').value.trim();
        const amount=parseFloat(document.getElementById('incomeAmount').value);
        if(!name||isNaN(amount)){UI.toast('Fill required fields');return}
        
        const income={name,amount,frequency:document.getElementById('incomeFrequency').value,payDay:parseInt(document.getElementById('incomePayDay').value)||null};
        const editId=document.getElementById('editingIncomeId').value;
        
        if(editId){
            const idx=data.income.findIndex(i=>i.id===parseInt(editId));
            if(idx>=0){income.id=parseInt(editId);data.income[idx]=income;}
        }else{
            income.id=Date.now();
            if(!data.income)data.income=[];
            data.income.push(income);
        }
        
        DataManager.save();
        Modals.close('incomeModal');
        this.render();
        CashFlow.render();
        UI.toast('✓ Saved!','success');
    },
    
    delete(id){
        if(!confirm('Delete?'))return;
        data.income=data.income.filter(i=>i.id!==id);
        DataManager.save();
        this.render();
        CashFlow.render();
    }
};

// ============================================================
// CASH FLOW FORECASTING
// ============================================================
const CashFlow={
    render(){
        const el=document.getElementById('cashFlowForecast');
        if(!el)return;
        
        const monthlyIncome=Income.getMonthlyTotal();
        const monthlyBills=(data.bills||[]).reduce((s,b)=>s+b.amount,0);
        const monthlyMinPayments=(data.debts||[]).reduce((s,d)=>s+(d.minPayment||0),0);
        const monthlyExpenses=this.getAvgMonthlyExpenses();
        
        // Show breakdown: fixed vs discretionary
        const totalOutflow=monthlyBills+monthlyMinPayments+monthlyExpenses;
        const surplus=monthlyIncome-totalOutflow;
        
        const checkingBalance=(data.assets||[]).filter(a=>['checking','savings'].includes(a.type)).reduce((s,a)=>s+a.balance,0);
        
        el.innerHTML=`
            <div class="cashflow-grid">
                <div class="cashflow-item income"><div class="cf-label">Monthly Income</div><div class="cf-value">${fmt(monthlyIncome)}</div></div>
                <div class="cashflow-item expense"><div class="cf-label">Bills & Subs</div><div class="cf-value">-${fmt(monthlyBills)}</div></div>
                <div class="cashflow-item expense"><div class="cf-label">Debt Minimums</div><div class="cf-value">-${fmt(monthlyMinPayments)}</div></div>
                <div class="cashflow-item expense"><div class="cf-label">Discretionary Spending</div><div class="cf-value">-${fmt(monthlyExpenses)}</div>
                    <div class="cf-hint">Avg from transactions, excluding bills & debt payments</div>
                </div>
                <div class="cashflow-item ${surplus>=0?'surplus':'deficit'}"><div class="cf-label">${surplus>=0?'Monthly Surplus':'Monthly Deficit'}</div><div class="cf-value">${surplus>=0?'+':''}${fmt(surplus)}</div></div>
            </div>
            <h4>Balance Forecast</h4>
            <div class="forecast-grid">
                ${[30,60,90].map(days=>{
                    const projected=checkingBalance+(surplus*(days/30));
                    return`<div class="forecast-item ${projected<0?'danger':''}"><div class="forecast-days">${days} Days</div><div class="forecast-balance">${fmt(projected)}</div></div>`;
                }).join('')}
            </div>
            ${surplus<0?`<div class="cashflow-warning">⚠️ You're spending more than you earn. Review expenses or increase income.</div>`:''}
            ${checkingBalance+(surplus*3)<0?`<div class="cashflow-warning">⚠️ At current rate, you may run out of funds within 90 days.</div>`:''}
        `;
    },
    
    getAvgMonthlyExpenses(){
        // Get average discretionary spending, EXCLUDING transactions that match bills/recurring
        const billNames=(data.bills||[]).map(b=>b.name.toLowerCase());
        const debtNames=(data.debts||[]).map(d=>d.name.toLowerCase());
        
        const now=new Date();
        let total=0;
        let monthsWithData=0;
        
        for(let i=0;i<3;i++){
            const month=now.getMonth()-i;
            const year=now.getFullYear()+(month<0?-1:0);
            const m=(month+12)%12;
            const txns=(data.transactions||[]).filter(t=>{
                if(t.type!=='expense')return false;
                const d=new Date(t.date);
                if(d.getMonth()!==m||d.getFullYear()!==year)return false;
                
                // Exclude transactions that look like bills or debt payments
                const desc=t.description.toLowerCase();
                const isBillPayment=billNames.some(b=>desc.includes(b));
                const isDebtPayment=debtNames.some(d=>desc.includes(d));
                const isLoanPayment=desc.match(/payment|autopay|auto pay|min pay|minimum|loan pmt/i);
                const isRentMortgage=desc.match(/rent|mortgage|lease/i);
                const isUtility=desc.match(/electric|water|sewer|internet|comcast|verizon|at&t|t-mobile|xfinity/i);
                const isInsurance=desc.match(/insurance|geico|progressive|state farm|allstate/i);
                
                return !isBillPayment&&!isDebtPayment&&!isLoanPayment&&!isRentMortgage&&!isUtility&&!isInsurance;
            });
            
            const monthTotal=txns.reduce((s,t)=>s+t.amount,0);
            if(monthTotal>0)monthsWithData++;
            total+=monthTotal;
        }
        
        return monthsWithData>0?total/monthsWithData:0;
    }
};

// ============================================================
// WHAT-IF SCENARIOS
// ============================================================
const WhatIf={
    calculate(){
        const eligible=getEligibleDebts();
        if(eligible.length===0)return;
        
        const baseExtra=parseFloat(document.getElementById('strategyExtra')?.value)||500;
        const extraPayment=parseFloat(document.getElementById('whatIfExtra')?.value)||0;
        const windfall=parseFloat(document.getElementById('whatIfWindfall')?.value)||0;
        const rateChange=parseFloat(document.getElementById('whatIfRate')?.value)||0;
        
        // Baseline
        const baseline=Strategy.simulate(eligible,baseExtra,'avalanche');
        
        // Modified debts
        let modified=[...eligible].map(d=>({...d}));
        
        // Apply windfall to highest rate
        if(windfall>0){
            modified.sort((a,b)=>b.rate-a.rate);
            let remaining=windfall;
            for(const d of modified){
                const apply=Math.min(remaining,d.balance);
                d.balance-=apply;
                remaining-=apply;
                if(remaining<=0)break;
            }
        }
        
        // Apply rate change
        if(rateChange!==0){
            modified=modified.map(d=>({...d,rate:Math.max(0,d.rate+rateChange)}));
        }
        
        const newExtra=baseExtra+extraPayment;
        const scenario=Strategy.simulate(modified.filter(d=>d.balance>0),newExtra,'avalanche');
        
        const timeDiff=baseline.months-scenario.months;
        const intDiff=baseline.totalInt-scenario.totalInt;
        
        document.getElementById('whatIfResults').innerHTML=`
            <div class="whatif-compare">
                <div class="whatif-col"><h4>Current Plan</h4>
                    <div class="whatif-stat">${baseline.freedomDate.toLocaleDateString('en-US',{month:'short',year:'numeric'})}</div>
                    <div class="whatif-label">${baseline.months} months</div>
                    <div class="whatif-stat">${fmt(baseline.totalInt)}</div>
                    <div class="whatif-label">Total Interest</div>
                </div>
                <div class="whatif-arrow">→</div>
                <div class="whatif-col highlight"><h4>New Scenario</h4>
                    <div class="whatif-stat">${scenario.freedomDate.toLocaleDateString('en-US',{month:'short',year:'numeric'})}</div>
                    <div class="whatif-label">${scenario.months} months</div>
                    <div class="whatif-stat">${fmt(scenario.totalInt)}</div>
                    <div class="whatif-label">Total Interest</div>
                </div>
            </div>
            <div class="whatif-summary ${timeDiff>0?'positive':timeDiff<0?'negative':''}">
                ${timeDiff>0?`✅ ${timeDiff} months faster! Save ${fmt(intDiff)} in interest.`:timeDiff<0?`⚠️ ${Math.abs(timeDiff)} months longer. ${fmt(Math.abs(intDiff))} more interest.`:'No change.'}
            </div>
        `;
    }
};

// ============================================================
// DEBT NEGOTIATION SCRIPTS
// ============================================================
const DebtNegotiation={
    scripts:{
        rateReduction:{title:'Rate Reduction',when:'Good payment history (6+ months on-time)',
            script:`Hi, I've been a customer for [X time] with on-time payments. My APR is [X]% and I'd like to request a rate reduction. I've seen offers at lower rates elsewhere. What can you do for me?`},
        hardship:{title:'Hardship Program',when:'Financial difficulty (job loss, medical)',
            script:`I'm experiencing financial hardship due to [reason]. I want to continue payments but need assistance. Do you have hardship programs that could temporarily reduce my rate or payment?`},
        balanceTransfer:{title:'Balance Transfer Counter',when:'Good credit, considering moving debt',
            script:`I'm considering transferring my balance to a 0% intro offer. Before I do, can you match or beat that to keep my business?`},
        settlement:{title:'Settlement (Last Resort)',when:'Seriously delinquent, can pay lump sum',
            script:`I've fallen behind and want to resolve this. I can offer [X]% as a lump sum to settle in full today. Can we work something out?`}
    },
    
    show(debtId){
        const debt=data.debts.find(d=>d.id===debtId);
        if(!debt)return;
        
        document.getElementById('negotiationDebtName').textContent=debt.name;
        document.getElementById('negotiationScripts').innerHTML=Object.entries(this.scripts).map(([k,s])=>`
            <div class="script-card">
                <div class="script-title">${s.title}</div>
                <div class="script-when">📌 ${s.when}</div>
                <div class="script-text">${s.script.replace('[X]%',debt.rate+'%')}</div>
                <button class="btn btn-sm" onclick="navigator.clipboard.writeText(this.previousElementSibling.textContent);UI.toast('Copied!','success')">📋 Copy</button>
            </div>
        `).join('')+`
            <div class="negotiation-tips">
                <h4>💡 Tips</h4>
                <ul>
                    <li>Call early morning for shorter waits</li>
                    <li>Be polite but firm</li>
                    <li>Ask for supervisor if needed</li>
                    <li>Get agreements in writing</li>
                    <li>Note: date, rep name, reference #</li>
                </ul>
            </div>
        `;
        Modals.show('negotiationModal');
    }
};

// ============================================================
// DAILY MONEY MINUTE
// ============================================================
const DailyCheckin={
    show(){
        if(!data.debts||data.debts.length===0)return;
        
        const today=new Date();
        const todayStr=today.toDateString();
        if(data.lastCheckin===todayStr)return;
        
        const todaySpent=(data.transactions||[]).filter(t=>t.type==='expense'&&new Date(t.date).toDateString()===todayStr).reduce((s,t)=>s+t.amount,0);
        const upcomingBills=(data.bills||[]).filter(b=>{
            const d=b.dueDay-today.getDate();
            return d>=0&&d<=7;
        });
        const nextPayoff=Strategy.simulate(getEligibleDebts(),500,'avalanche').timeline[0];
        
        document.getElementById('checkinContent').innerHTML=`
            <div class="checkin-stat"><div class="checkin-label">Today's Spending</div><div class="checkin-value">${fmt(todaySpent)}</div></div>
            ${upcomingBills.length>0?`<div class="checkin-stat"><div class="checkin-label">Bills Next 7 Days</div><div class="checkin-value">${fmt(upcomingBills.reduce((s,b)=>s+b.amount,0))}</div><div class="checkin-list">${upcomingBills.map(b=>b.name).join(', ')}</div></div>`:''}
            ${nextPayoff?`<div class="checkin-stat highlight"><div class="checkin-label">Next Payoff Target</div><div class="checkin-value">${nextPayoff.name}</div><div class="checkin-sub">${nextPayoff.date.toLocaleDateString('en-US',{month:'short',year:'numeric'})}</div></div>`:''}
            <div class="checkin-motivation">${this.getMotivation()}</div>
        `;
        Modals.show('checkinModal');
    },
    
    getMotivation(){
        const messages=['Every payment gets you closer to freedom!','Small steps lead to big wins.','You\'re making progress every day!','Stay focused on your goal!','Financial freedom is worth the sacrifice.'];
        return messages[Math.floor(Math.random()*messages.length)];
    },
    
    complete(){
        data.lastCheckin=new Date().toDateString();
        DataManager.save();
        Modals.close('checkinModal');
        Achievements.checkStreak();
    },
    
    skip(){
        data.lastCheckin=new Date().toDateString();
        DataManager.save();
        Modals.close('checkinModal');
    }
};

// ============================================================
// SPENDING STREAKS
// ============================================================
const SpendingStreak={
    check(){
        const today=new Date().toDateString();
        if(!data.spendingStreak)data.spendingStreak={current:0,best:0,lastDate:null};
        if(data.spendingStreak.lastDate===today)return;
        
        const wasUnderBudget=this.checkYesterdayBudget();
        const yesterday=new Date(Date.now()-86400000).toDateString();
        
        if(data.spendingStreak.lastDate===yesterday&&wasUnderBudget){
            data.spendingStreak.current++;
            if(data.spendingStreak.current>data.spendingStreak.best){
                data.spendingStreak.best=data.spendingStreak.current;
            }
            if(data.spendingStreak.current===7)UI.toast('🔥 7-day budget streak!','success');
            if(data.spendingStreak.current===30)UI.toast('⚡ 30-day budget streak!','success');
        }else if(!wasUnderBudget){
            data.spendingStreak.current=0;
        }
        
        data.spendingStreak.lastDate=today;
        DataManager.save();
    },
    
    checkYesterdayBudget(){
        if(!data.budgetCategories||data.budgetCategories.length===0)return true;
        const yesterday=new Date(Date.now()-86400000);
        const dailySpending=(data.transactions||[]).filter(t=>t.type==='expense'&&new Date(t.date).toDateString()===yesterday.toDateString()).reduce((s,t)=>s+t.amount,0);
        const dailyBudget=data.budgetCategories.reduce((s,c)=>s+c.limit,0)/30;
        return dailySpending<=dailyBudget*1.1;
    },
    
    render(){
        const el=document.getElementById('streakDisplay');
        if(!el||!data.spendingStreak)return;
        el.innerHTML=`<div class="streak-current">🔥 ${data.spendingStreak.current} day streak</div><div class="streak-best">Best: ${data.spendingStreak.best} days</div>`;
    }
};

// ============================================================
// MILESTONES & CELEBRATIONS
// ============================================================
const Milestones={
    check(){
        const eligible=getEligibleDebts();
        const totalOrig=eligible.reduce((s,d)=>s+(d.originalBalance||d.balance),0);
        const totalCurr=eligible.reduce((s,d)=>s+d.balance,0);
        const pct=totalOrig>0?((totalOrig-totalCurr)/totalOrig*100):0;
        
        if(!data.milestones)data.milestones=[];
        
        const milestones=[{pct:10,id:'10pct',msg:'10% paid off!'},{pct:25,id:'25pct',msg:'Quarter way there!'},{pct:50,id:'50pct',msg:'HALFWAY!'},{pct:75,id:'75pct',msg:'75% complete!'},{pct:100,id:'100pct',msg:'DEBT FREE!'}];
        
        for(const m of milestones){
            if(pct>=m.pct&&!data.milestones.includes(m.id)){
                data.milestones.push(m.id);
                this.celebrate(m.msg,pct);
                DataManager.save();
                break;
            }
        }
    },
    
    celebrate(msg,pct){
        UI.confetti();
        document.getElementById('celebrationTitle').textContent='🎉 '+msg;
        document.getElementById('celebrationMessage').textContent=`You've paid off ${pct.toFixed(0)}% of your consumer debt!`;
        Modals.show('celebrationModal');
    },
    
    render(){
        const el=document.getElementById('milestoneTrack');
        if(!el)return;
        
        const eligible=getEligibleDebts();
        const totalOrig=eligible.reduce((s,d)=>s+(d.originalBalance||d.balance),0);
        const totalCurr=eligible.reduce((s,d)=>s+d.balance,0);
        const pct=totalOrig>0?((totalOrig-totalCurr)/totalOrig*100):0;
        
        el.innerHTML=[10,25,50,75,100].map(m=>`<div class="milestone ${pct>=m?'achieved':''}">${m}%</div>`).join('<div class="milestone-line"></div>');
    }
};

// ============================================================
// NET WORTH HISTORY
// ============================================================
const NetWorthHistory={
    record(){
        const monthKey=new Date().toISOString().slice(0,7);
        if(!data.netWorthHistory)data.netWorthHistory=[];
        if(data.netWorthHistory.find(h=>h.month===monthKey))return;
        
        const assets=(data.assets||[]).reduce((s,a)=>s+a.balance,0);
        const debts=(data.debts||[]).reduce((s,d)=>s+d.balance,0);
        data.netWorthHistory.push({month:monthKey,assets,debts,netWorth:assets-debts});
        
        if(data.netWorthHistory.length>24)data.netWorthHistory=data.netWorthHistory.slice(-24);
        DataManager.save();
    },
    
    render(){
        const el=document.getElementById('netWorthChart');
        if(!el||!data.netWorthHistory||data.netWorthHistory.length<2)return;
        
        const history=data.netWorthHistory.slice(-6);
        const max=Math.max(...history.map(h=>Math.abs(h.netWorth)),1);
        
        el.innerHTML=`<h4>Net Worth Trend</h4><div class="nw-chart">${history.map(h=>{
            const height=Math.abs(h.netWorth)/max*100;
            return`<div class="nw-bar-wrap"><div class="nw-bar ${h.netWorth<0?'negative':''}" style="height:${height}%"></div><div class="nw-label">${h.month.slice(5)}</div></div>`;
        }).join('')}</div>`;
    }
};

// ============================================================
// TIP JAR
// ============================================================
const TipJar={
    show(){
        Modals.show('tipJarModal');
    }
};

// ============================================================
// EXTEND MODALS
// ============================================================
Modals.showIncome=function(id=null){
    if(id){
        const i=data.income?.find(x=>x.id===id);
        if(!i)return;
        document.getElementById('incomeModalTitle').textContent='Edit Income';
        document.getElementById('editingIncomeId').value=id;
        document.getElementById('incomeName').value=i.name;
        document.getElementById('incomeAmount').value=i.amount;
        document.getElementById('incomeFrequency').value=i.frequency||'monthly';
        document.getElementById('incomePayDay').value=i.payDay||'';
    }else{
        document.getElementById('incomeModalTitle').textContent='Add Income';
        document.getElementById('editingIncomeId').value='';
        ['incomeName','incomeAmount','incomePayDay'].forEach(x=>document.getElementById(x).value='');
        document.getElementById('incomeFrequency').value='monthly';
    }
    this.show('incomeModal');
};

Modals.showWhatIf=function(){
    document.getElementById('whatIfExtra').value='100';
    document.getElementById('whatIfWindfall').value='';
    document.getElementById('whatIfRate').value='';
    WhatIf.calculate();
    this.show('whatIfModal');
};

// ============================================================
// EXTEND APP.RENDERALL
// ============================================================
const originalRenderAll=App.renderAll;
App.renderAll=function(){
    originalRenderAll.call(this);
    try{
        Income.render();
        CashFlow.render();
        SpendingStreak.render();
        Milestones.render();
        NetWorthHistory.render();
    }catch(e){console.error('Extended render error:',e);}
};

// ============================================================
// EXTEND APP.UNLOCK
// ============================================================
const originalUnlock=App.unlock;
App.unlock=function(){
    originalUnlock.call(this);
    NetWorthHistory.record();
    Milestones.check();
    SpendingStreak.check();
    setTimeout(()=>DailyCheckin.show(),1500);
};

// ============================================================
// MISSING MODAL OPENERS
// ============================================================
Modals.showTransaction=function(){
    document.getElementById('transactionDesc').value='';
    document.getElementById('transactionAmount').value='';
    document.getElementById('transactionDate').value=new Date().toISOString().split('T')[0];
    document.getElementById('transactionType').value='expense';
    document.getElementById('transactionCategory').value='other';
    this.show('transactionModal');
};

Modals.showBudgetCategory=function(){
    document.getElementById('budgetCategorySelect').value='groceries';
    document.getElementById('budgetLimit').value='';
    this.show('budgetCategoryModal');
};

// ============================================================
// CALCULATORS
// ============================================================
const Calc={
    showTab(tab,btn){
        document.querySelectorAll('.calc-tab-content').forEach(c=>c.style.display='none');
        document.querySelectorAll('.tabs .tab').forEach(t=>t.classList.remove('active'));
        const el=document.getElementById('calc-'+tab);
        if(el)el.style.display='block';
        if(btn)btn.classList.add('active');
        if(tab==='consolidation'){
            const eligible=getEligibleDebts();
            const countEl=document.getElementById('consolidationDebtCount');
            const totalEl=document.getElementById('consolidationDebtTotal');
            if(countEl)countEl.textContent=eligible.length;
            if(totalEl)totalEl.textContent=fmt(eligible.reduce((s,d)=>s+d.balance,0));
        }
    },

    balanceTransfer(){
        const balance=parseFloat(document.getElementById('btCurrentBalance').value)||0;
        const currentAPR=parseFloat(document.getElementById('btCurrentAPR').value)||0;
        const monthly=parseFloat(document.getElementById('btMonthlyPayment').value)||0;
        const introAPR=parseFloat(document.getElementById('btIntroAPR').value)||0;
        const introPeriod=parseInt(document.getElementById('btIntroPeriod').value)||18;
        const fee=parseFloat(document.getElementById('btTransferFee').value)||3;
        const regularAPR=parseFloat(document.getElementById('btRegularAPR').value)||0;

        if(!balance||!monthly){UI.toast('Fill in balance and payment');return}

        // Current path
        let currBal=balance,currInt=0,currMonths=0;
        while(currBal>0&&currMonths<360){
            currMonths++;
            const int=currBal*currentAPR/100/12;
            currInt+=int;
            currBal=currBal+int-Math.min(monthly,currBal+int);
        }

        // BT path
        const btFee=balance*fee/100;
        let btBal=balance+btFee,btInt=0,btMonths=0;
        while(btBal>0&&btMonths<360){
            btMonths++;
            const rate=btMonths<=introPeriod?introAPR:regularAPR;
            const int=btBal*rate/100/12;
            btInt+=int;
            btBal=btBal+int-Math.min(monthly,btBal+int);
        }

        const savings=currInt-btInt-btFee;
        document.getElementById('btResult').innerHTML=`
            <div class="calc-result ${savings>0?'positive':'negative'}">
                <h4>${savings>0?'✅ Transfer saves you money':'⚠️ Transfer may not be worth it'}</h4>
                <div class="calc-compare">
                    <div><strong>Current Path</strong><br>${currMonths} months<br>${fmt(currInt)} interest</div>
                    <div><strong>Balance Transfer</strong><br>${btMonths} months<br>${fmt(btInt)} interest + ${fmt(btFee)} fee</div>
                </div>
                <div class="calc-savings">${savings>0?'Net savings: '+fmt(savings):'Net cost: '+fmt(Math.abs(savings))}</div>
            </div>`;
    },

    consolidation(){
        const eligible=getEligibleDebts();
        const totalDebt=eligible.reduce((s,d)=>s+d.balance,0);
        const apr=parseFloat(document.getElementById('consAPR').value)||0;
        const term=parseInt(document.getElementById('consTerm').value)||48;
        const fee=parseFloat(document.getElementById('consFee').value)||0;

        if(!apr||!term){UI.toast('Fill in APR and term');return}

        const loanAmount=totalDebt*(1+fee/100);
        const monthlyRate=apr/100/12;
        const payment=loanAmount*monthlyRate/(1-Math.pow(1+monthlyRate,-term));
        const totalPaid=payment*term;
        const totalInt=totalPaid-totalDebt;

        // Current path
        const extra=parseFloat(document.getElementById('strategyExtra')?.value)||500;
        const current=Strategy.simulate(eligible,extra,'avalanche');

        const savings=current.totalInt-totalInt;

        document.getElementById('consResult').innerHTML=`
            <div class="calc-result ${savings>0?'positive':'negative'}">
                <h4>${savings>0?'✅ Consolidation could save you':'⚠️ Stay with current plan'}</h4>
                <div class="calc-compare">
                    <div><strong>Current Plan</strong><br>${current.months} months<br>${fmt(current.totalInt)} interest<br>${fmt(extra+eligible.reduce((s,d)=>s+(d.minPayment||25),0))}/mo</div>
                    <div><strong>Consolidation</strong><br>${term} months<br>${fmt(totalInt)} interest<br>${fmt(Math.round(payment))}/mo</div>
                </div>
                <div class="calc-savings">${savings>0?'Saves '+fmt(savings)+' in interest':'Costs '+fmt(Math.abs(savings))+' more in interest'}</div>
            </div>`;
    },

    refinance(){
        const amount=parseFloat(document.getElementById('refiAmount').value)||0;
        const apr=parseFloat(document.getElementById('refiAPR').value)||0;
        const term=parseInt(document.getElementById('refiTerm').value)||60;
        const type=document.getElementById('refiType').value;

        if(!amount||!apr){UI.toast('Fill in amount and APR');return}

        const monthlyRate=apr/100/12;
        const payment=amount*monthlyRate/(1-Math.pow(1+monthlyRate,-term));
        const totalPaid=payment*term;
        const totalInt=totalPaid-amount;

        let warning='';
        if(type==='401k')warning='<div class="cashflow-warning">⚠️ 401k loans: If you leave your job, the full balance may become due. You also miss out on market gains.</div>';
        if(type==='heloc')warning='<div class="cashflow-warning">⚠️ HELOCs put your home at risk. Make sure you can afford the payments.</div>';

        document.getElementById('refiResult').innerHTML=`
            <div class="calc-result">
                <div class="calc-compare">
                    <div><strong>Monthly Payment</strong><br>${fmt(Math.round(payment))}</div>
                    <div><strong>Total Interest</strong><br>${fmt(Math.round(totalInt))}</div>
                    <div><strong>Total Cost</strong><br>${fmt(Math.round(totalPaid))}</div>
                </div>
                ${warning}
            </div>`;
    }
};

// ============================================================
// EXPORT CSV
// ============================================================
DataManager.exportCSV=function(){
    let csv='Account,Balance,Rate,MinPayment,Type,Status\n';
    (data.debts||[]).forEach(d=>{
        csv+=`"${d.name}",${d.balance},${d.rate},${d.minPayment||0},${d.type},${d.excludeFromPlan?'excluded':'active'}\n`;
    });
    csv+='\nAsset,Balance,Type\n';
    (data.assets||[]).forEach(a=>{
        csv+=`"${a.name}",${a.balance},${a.type}\n`;
    });
    const blob=new Blob([csv],{type:'text/csv'});
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='debtforge-export-'+new Date().toISOString().split('T')[0]+'.csv';
    a.click();
    UI.toast('✓ CSV exported!','success');
};

// ============================================================
// SHARE COPY
// ============================================================
Share.copy=function(){
    const stats=calcStats();
    const text=`🎯 Debt Freedom Journey\n${stats.eligibleCount} debts • ${fmt(stats.eligibleTotal)} remaining\nAvg rate: ${stats.avgRate.toFixed(1)}%\nMonthly interest: ${fmt(stats.eligibleMonthlyInt)}`;
    navigator.clipboard?.writeText(text).then(()=>UI.toast('✓ Copied!','success')).catch(()=>UI.toast('Copy failed'));
    Modals.close('shareModal');
};

// ============================================================
// TIP JAR
// ============================================================
TipJar.tip=function(amount){
    UI.toast('💜 Thank you for the $'+amount+' tip! (Payment integration coming soon)','success');
    UI.confetti();
    Modals.close('tipJarModal');
};
